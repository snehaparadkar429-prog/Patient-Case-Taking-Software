import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { Patient } from '../../patients/entities/patient.entity';

@Entity('observations')
@Index(['patientId'])
@Index(['code'])
@Index(['category'])
export class Observation {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  patientId: string;

  @ManyToOne(() => Patient)
  @JoinColumn({ name: 'patientId' })
  patient: Patient;

  // FHIR Observation.status
  @Column({ length: 50, default: 'final' })
  status: string;

  // FHIR Observation.category (vital-signs, lab, etc.)
  @Column({ type: 'simple-json', nullable: true })
  category: Array<{ coding: Array<{ system: string; code: string }> }>;

  // FHIR Observation.code (LOINC)
  @Column({ type: 'simple-json' })
  code: { coding: Array<{ system: string; code: string; display?: string }> };

  @Column({ type: 'datetime', nullable: true })
  effectiveDateTime: Date;

  // FHIR Observation.value[x] - polymorphic
  @Column({ type: 'simple-json', nullable: true })
  valueQuantity: { value: number; unit: string; system?: string; code?: string };

  @Column({ type: 'text', nullable: true })
  valueString: string;

  @Column({ type: 'text', nullable: true })
  encounterId: string;

  @Column({ type: 'text', nullable: true })
  clinicianId: string;

  @CreateDateColumn()
  createdAt: Date;
}
