import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, LessThan } from 'typeorm';
import { AuditLog } from './entities/audit-log.entity';
import { AuditAction, HIPAA_CONFIG } from '@pct/shared';
import { generateId } from '@pct/shared';

export interface AuditLogEntry {
  action: AuditAction;
  resourceType?: string;
  resourceId?: string;
  userId?: string;
  userRole?: string;
  ipAddress?: string;
  userAgent?: string;
  patientId?: string;
  encounterId?: string;
  facilityId?: string;
  reason?: string;
  status?: string;
  errorMessage?: string;
  isBreakGlass?: boolean;
  breakGlassJustification?: string;
  requestPath?: string;
  requestMethod?: string;
  responseTimeMs?: number;
}

/**
 * HIPAA § 164.312(b): Audit Controls
 * HIPAA § 164.308(a)(1)(ii)(D): Information System Activity Review
 *
 * Immutable audit logging service. Every access to PHI must be logged.
 * In production, this should write to an append-only ledger (Amazon QLDB)
 * to guarantee immutability and tamper-evidence.
 *
 * Log format conforms to DICOM ATNA / RFC 5424 standard.
 */
@Injectable()
export class AuditService {
  constructor(
    @InjectRepository(AuditLog)
    private auditRepository: Repository<AuditLog>
  ) {}

  /**
   * Log a PHI access or system event.
   * This is the primary audit logging method called throughout the application.
   *
   * HIPAA: This method must NEVER be async-disabled or wrapped in try/catch
   * that swallows errors - audit log failures should raise alerts.
   */
  async log(entry: AuditLogEntry): Promise<AuditLog> {
    const auditLog = this.auditRepository.create({
      eventId: generateId('evt'),
      timestamp: new Date(),
      action: entry.action,
      resourceType: entry.resourceType,
      resourceId: entry.resourceId,
      userId: entry.userId,
      userRole: entry.userRole,
      ipAddress: entry.ipAddress,
      userAgent: entry.userAgent?.substring(0, 500),
      patientId: entry.patientId,
      encounterId: entry.encounterId,
      facilityId: entry.facilityId,
      reason: entry.reason,
      status: entry.status || 'SUCCESS',
      errorMessage: entry.errorMessage,
      isBreakGlass: entry.isBreakGlass || false,
      breakGlassJustification: entry.breakGlassJustification,
      requestPath: entry.requestPath,
      requestMethod: entry.requestMethod,
      responseTimeMs: entry.responseTimeMs,
    });

    try {
      const saved = await this.auditRepository.save(auditLog) as AuditLog;
      return saved;
    } catch (error: any) {
      // HIPAA: Audit log failures are critical - log to stderr and external monitoring
      console.error(
        '[CRITICAL] Failed to write audit log:',
        JSON.stringify({
          eventId: auditLog.eventId,
          action: auditLog.action,
          userId: auditLog.userId,
          error: error?.message || String(error),
        })
      );
      // In production: trigger PagerDuty / OpsGenie alert
      throw error;
    }
  }

  /**
   * Query audit logs with filtering and pagination.
   * Used by compliance officers for HIPAA access reviews.
   */
  async findAll(filters: {
    userId?: string;
    patientId?: string;
    action?: AuditAction;
    resourceType?: string;
    startDate?: Date;
    endDate?: Date;
    ipAddress?: string;
    isBreakGlass?: boolean;
    page?: number;
    limit?: number;
  }): Promise<{ logs: AuditLog[]; total: number }> {
    const page = filters.page || 1;
    const limit = Math.min(filters.limit || 50, 100);

    const query = this.auditRepository.createQueryBuilder('audit');

    if (filters.userId) {
      query.andWhere('audit.userId = :userId', { userId: filters.userId });
    }

    if (filters.patientId) {
      query.andWhere('audit.patientId = :patientId', {
        patientId: filters.patientId,
      });
    }

    if (filters.action) {
      query.andWhere('audit.action = :action', { action: filters.action });
    }

    if (filters.resourceType) {
      query.andWhere('audit.resourceType = :resourceType', {
        resourceType: filters.resourceType,
      });
    }

    if (filters.startDate) {
      query.andWhere('audit.timestamp >= :startDate', {
        startDate: filters.startDate,
      });
    }

    if (filters.endDate) {
      query.andWhere('audit.timestamp <= :endDate', {
        endDate: filters.endDate,
      });
    }

    if (filters.ipAddress) {
      query.andWhere('audit.ipAddress = :ipAddress', {
        ipAddress: filters.ipAddress,
      });
    }

    if (filters.isBreakGlass !== undefined) {
      query.andWhere('audit.isBreakGlass = :isBreakGlass', {
        isBreakGlass: filters.isBreakGlass,
      });
    }

    query.orderBy('audit.timestamp', 'DESC');
    query.skip((page - 1) * limit);
    query.take(limit);

    const [logs, total] = await query.getManyAndCount();

    return { logs, total };
  }

  /**
   * Get audit statistics for anomaly detection.
   * Used by SEC-03 HIPAA Access & Anomaly Reports.
   */
  async getAnomalyStats(facilityId: string, dateRange: { start: Date; end: Date }) {
    const query = this.auditRepository.createQueryBuilder('audit');

    query.select([
      'audit.userId',
      'audit.userRole',
      'audit.action',
      'COUNT(*) as accessCount',
    ]);

    query.where('audit.facilityId = :facilityId', { facilityId });
    query.andWhere('audit.timestamp BETWEEN :start AND :end', {
      start: dateRange.start,
      end: dateRange.end,
    });

    query.groupBy('audit.userId');
    query.addGroupBy('audit.userRole');
    query.addGroupBy('audit.action');

    return query.getRawMany();
  }

  /**
   * Find bulk access patterns (potential data breach indicator).
   * SEC-03: Detect unusual bulk data downloads.
   */
  async detectBulkAccess(userId: string, hoursBack: number = 1) {
    const since = new Date(Date.now() - hoursBack * 60 * 60 * 1000);

    const count = await this.auditRepository
      .createQueryBuilder('audit')
      .where('audit.userId = :userId', { userId })
      .andWhere('audit.timestamp > :since', { since })
      .andWhere('audit.action = :action', { action: AuditAction.READ })
      .getCount();

    return {
      userId,
      hoursBack,
      readCount: count,
      isAnomaly: count > 100, // Threshold: >100 reads in 1 hour
    };
  }

  /**
   * HIPAA: Retention management - archive old audit logs
   * while maintaining the required 7-year retention period.
   */
  async getRetentionStats() {
    const retentionDate = new Date(
      Date.now() - HIPAA_CONFIG.AUDIT_LOG_RETENTION_DAYS * 24 * 60 * 60 * 1000
    );

    const totalCount = await this.auditRepository.count();
    const expiredCount = await this.auditRepository.count({
      where: { createdAt: LessThan(retentionDate) },
    });

    return {
      totalCount,
      expiredCount,
      retentionDate,
      retentionYears: HIPAA_CONFIG.AUDIT_LOG_RETENTION_DAYS / 365,
    };
  }
}
