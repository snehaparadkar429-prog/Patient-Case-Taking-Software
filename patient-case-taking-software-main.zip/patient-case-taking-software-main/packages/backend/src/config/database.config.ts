import { ConfigService } from '@nestjs/config';
import { TypeOrmModuleOptions } from '@nestjs/typeorm';
import { User } from '../modules/auth/entities/user.entity';
import { Patient } from '../modules/patients/entities/patient.entity';
import { IntakeForm } from '../modules/intake/entities/intake-form.entity';
import { AuditLog } from '../modules/audit/entities/audit-log.entity';
import { Encounter } from '../modules/fhir/entities/encounter.entity';
import { Condition } from '../modules/fhir/entities/condition.entity';
import { AllergyIntolerance } from '../modules/fhir/entities/allergy-intolerance.entity';
import { Observation } from '../modules/fhir/entities/observation.entity';

const entities = [
  User,
  Patient,
  IntakeForm,
  AuditLog,
  Encounter,
  Condition,
  AllergyIntolerance,
  Observation,
];

export function databaseConfig(config: ConfigService): TypeOrmModuleOptions {
  const dbDriver = config.get<string>('DB_DRIVER', 'sqlite');

  // SQLite for development (no Docker needed), PostgreSQL for production
  if (dbDriver === 'sqlite') {
    return {
      type: 'better-sqlite3',
      database: config.get<string>('SQLITE_DB_PATH', 'pct-development.db'),
      entities,
      synchronize: true,
      logging: ['error'],
    };
  }

  // PostgreSQL for production
  return {
    type: 'postgres',
    host: config.get<string>('DB_HOST', 'localhost'),
    port: config.get<number>('DB_PORT', 5432),
    username: config.get<string>('DB_USERNAME', 'pct_user'),
    password: config.get<string>('DB_PASSWORD'),
    database: config.get<string>('DB_NAME', 'patient_case_taking'),
    ssl: config.get<string>('NODE_ENV') === 'production'
      ? { rejectUnauthorized: true, ca: config.get<string>('DB_SSL_CA') }
      : false,
    entities,
    synchronize: config.get<string>('NODE_ENV') !== 'production',
    logging: config.get<string>('NODE_ENV') === 'development' ? ['query', 'error'] : ['error'],
    poolSize: 20,
    maxQueryExecutionTime: 30000,
  };
}
