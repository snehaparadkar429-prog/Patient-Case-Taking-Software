import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { Encounter } from './entities/encounter.entity';
import { Condition } from './entities/condition.entity';
import { AllergyIntolerance } from './entities/allergy-intolerance.entity';
import { Observation } from './entities/observation.entity';
import { FhirController } from './fhir.controller';
import { FhirService } from './fhir.service';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Encounter,
      Condition,
      AllergyIntolerance,
      Observation,
    ]),
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        secret: config.get<string>('JWT_SECRET'),
      }),
    }),
    AuditModule,
  ],
  controllers: [FhirController],
  providers: [FhirService],
  exports: [FhirService],
})
export class FhirModule {}
