/**
 * HIPAA § 164.312(e)(1): Transmission Security
 * API client with automatic token management and error handling.
 *
 * All requests go through the Next.js API proxy (/api/v1/*) which
 * server-side forwards to the backend. This avoids CORS and CSP issues.
 * The browser never makes cross-origin requests.
 */

// In the browser, requests to /api/* are proxied by Next.js to the backend.
// In Docker, NEXT_PUBLIC_API_URL can still be used for direct backend access.
const API_BASE = typeof window !== 'undefined'
  ? '/api' // Browser: use same-origin proxy via /api/*
  : (process.env.BACKEND_INTERNAL_URL || 'http://localhost:3001') + '/api/v1'; // Server-side fallback

interface ApiOptions {
  method?: string;
  body?: any;
  headers?: Record<string, string>;
}

class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
  }

  private getToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('accessToken');
  }

  private async request<T>(endpoint: string, options: ApiOptions = {}): Promise<T> {
    const { method = 'GET', body, headers = {} } = options;

    const token = this.getToken();

    const config: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...headers,
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
    };

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, config);

      // Handle token expiration
      if (response.status === 401) {
        if (typeof window !== 'undefined') {
          localStorage.removeItem('accessToken');
          localStorage.removeItem('refreshToken');
          window.location.href = '/login';
        }
        throw new Error('Session expired. Please sign in again.');
      }

      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        throw new Error(error.message || `Request failed: ${response.status}`);
      }

      // Handle 204 No Content
      if (response.status === 204) {
        return undefined as T;
      }

      return response.json();
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      }
      throw new Error('Network error. Please check your connection.');
    }
  }

  // ---- Auth ----
  async login(email: string, password: string) {
    return this.request<{
      accessToken: string;
      refreshToken: string;
      expiresIn: string;
      user: { id: string; email: string; firstName: string; lastName: string; role: string };
    }>('/auth/login', { method: 'POST', body: { email, password } });
  }

  async register(data: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    role: string;
  }) {
    return this.request<any>('/auth/register', { method: 'POST', body: data });
  }

  async getMe() {
    return this.request<any>('/auth/me');
  }

  // ---- Patients ----
  async getPatients(params?: { search?: string; page?: number; limit?: number }) {
    const query = new URLSearchParams();
    if (params?.search) query.set('search', params.search);
    if (params?.page) query.set('page', String(params.page));
    if (params?.limit) query.set('limit', String(params.limit));
    return this.request<any>(`/patients?${query.toString()}`);
  }

  async getPatient(id: string) {
    return this.request<any>(`/patients/${id}`);
  }

  async createPatient(data: any) {
    return this.request<any>('/patients', { method: 'POST', body: data });
  }

  // ---- Intake Forms ----
  async getIntakeForms(params?: { patientId?: string; status?: string; page?: number; limit?: number }) {
    const query = new URLSearchParams();
    if (params?.patientId) query.set('patientId', params.patientId);
    if (params?.status) query.set('status', params.status);
    if (params?.page) query.set('page', String(params.page));
    if (params?.limit) query.set('limit', String(params.limit));
    return this.request<any>(`/intake?${query.toString()}`);
  }

  async getIntakeForm(id: string) {
    return this.request<any>(`/intake/${id}`);
  }

  async createIntakeForm(data: any) {
    return this.request<any>('/intake', { method: 'POST', body: data });
  }

  async updateIntakeForm(id: string, data: any) {
    return this.request<any>(`/intake/${id}`, { method: 'PUT', body: data });
  }

  async submitIntakeForm(id: string) {
    return this.request<any>(`/intake/${id}/submit`, { method: 'POST' });
  }

  async reviewIntakeForm(id: string, reviewNotes: string, approve: boolean) {
    return this.request<any>(`/intake/${id}/review`, {
      method: 'POST',
      body: { reviewNotes, approve },
    });
  }

  async getCompletenessStats(patientId: string) {
    return this.request<any>(`/intake/completeness/${patientId}`);
  }

  // ---- FHIR ----
  async getFhirPatient(id: string) {
    return this.request<any>(`/patients/${id}/fhir`);
  }

  async getFhirConditions(patientId: string) {
    return this.request<any>(`/fhir/patient/${patientId}/conditions`);
  }

  async getFhirAllergies(patientId: string) {
    return this.request<any>(`/fhir/patient/${patientId}/allergies`);
  }

  // ---- Audit Logs ----
  async getAuditLogs(params?: any) {
    const query = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          query.set(key, String(value));
        }
      });
    }
    return this.request<any>(`/audit?${query.toString()}`);
  }
}

export const api = new ApiClient(API_BASE);
