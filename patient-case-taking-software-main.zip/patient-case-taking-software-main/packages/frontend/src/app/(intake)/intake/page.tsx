'use client';

import { useState, useCallback, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/stores/auth.store';
import { api } from '@/lib/api';
import { IntakeStepChiefComplaint } from '@/components/intake/StepChiefComplaint';
import { IntakeStepHPI } from '@/components/intake/StepHPI';
import { IntakeStepROS } from '@/components/intake/StepROS';
import { IntakeStepMedicalHistory } from '@/components/intake/StepMedicalHistory';
import { IntakeStepAllergies } from '@/components/intake/StepAllergies';
import { IntakeStepSocialHistory } from '@/components/intake/StepSocialHistory';
import { IntakeStepReview } from '@/components/intake/StepReview';

/**
 * INT-01: Smart Adaptive Intake Wizard
 * Dynamic, condition-based question flows that adjust based on
 * patient demographics, chief complaint, and historical risk factors.
 *
 * INT-02: Structured Chief Complaint & HPI Builder
 * Interactive clinical template using OPQRST format.
 */
export default function IntakeWizardPage() {
  const [currentStep, setCurrentStep] = useState(0);
  const [patientId, setPatientId] = useState<string | null>(null);
  const [formId, setFormId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    chiefComplaint: '',
    hpi: {
      onset: '',
      location: '',
      duration: '',
      character: '',
      aggravatingFactors: '',
      relievingFactors: '',
      timing: '',
      severity: 5,
      associatedSymptoms: [] as string[],
    },
    reviewOfSystems: {} as Record<string, string[]>,
    medicalHistory: {
      conditions: [] as Array<{ name: string; icdCode?: string; diagnosedDate?: string }>,
      surgeries: [] as Array<{ name: string; date?: string; notes?: string }>,
      medications: [] as Array<{ name: string; dosage: string; frequency: string; rxnormCode?: string }>,
      familyHistory: [] as Array<{ condition: string; relation: string }>,
    },
    allergies: [] as Array<{
      substance: string;
      reaction: string;
      severity: 'mild' | 'moderate' | 'severe';
      type: 'allergy' | 'intolerance';
    }>,
    socialHistory: {
      smokingStatus: '',
      alcoholUse: '',
      exerciseFrequency: '',
      occupation: '',
    },
  });

  const { user } = useAuthStore();
  const router = useRouter();

  const steps = [
    { id: 'chief-complaint', title: 'Chief Complaint', component: IntakeStepChiefComplaint },
    { id: 'hpi', title: 'History of Present Illness', component: IntakeStepHPI },
    { id: 'ros', title: 'Review of Systems', component: IntakeStepROS },
    { id: 'medical-history', title: 'Medical History', component: IntakeStepMedicalHistory },
    { id: 'allergies', title: 'Allergies & Medications', component: IntakeStepAllergies },
    { id: 'social-history', title: 'Social History', component: IntakeStepSocialHistory },
    { id: 'review', title: 'Review & Submit', component: IntakeStepReview },
  ];

  const updateFormData = useCallback((section: string, data: any) => {
    setFormData((prev) => ({
      ...prev,
      [section]: typeof data === 'function' ? data(prev[section as keyof typeof prev]) : data,
    }));
  }, []);

  const calculateProgress = (): number => {
    return Math.round(((currentStep + 1) / steps.length) * 100);
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      // Create or get patient record first
      if (!patientId) {
        const patient = await api.createPatient({
          name: [{ family: user?.lastName || 'Unknown', given: [user?.firstName || 'Patient'] }],
          gender: 'unknown',
          birthDate: '1990-01-01',
          telecom: [{ system: 'email', value: user?.email || '' }],
          address: [{ city: 'Unknown', state: 'XX', postalCode: '00000' }],
        });
        setPatientId(patient.id);

        // Create intake form
        const form = await api.createIntakeForm({
          patientId: patient.id,
          ...formData,
        });
        setFormId(form.id);

        // Submit for review
        await api.submitIntakeForm(form.id);
      } else if (formId) {
        // Update existing form
        await api.updateIntakeForm(formId, formData);
        await api.submitIntakeForm(formId);
      }

      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Failed to submit intake form. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const CurrentStepComponent = steps[currentStep].component;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-gray-900">
                Patient Intake
              </h1>
              <p className="text-sm text-gray-500">
                Step {currentStep + 1} of {steps.length}: {steps[currentStep].title}
              </p>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-500">Progress</div>
              <div className="flex items-center gap-2">
                <div className="w-32 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${calculateProgress()}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {calculateProgress()}%
                </span>
              </div>
            </div>
          </div>

          {/* Step indicator */}
          <nav className="mt-4 flex gap-1" aria-label="Progress">
            {steps.map((step, index) => (
              <button
                key={step.id}
                onClick={() => setCurrentStep(index)}
                className={`flex-1 h-1.5 rounded-full transition-colors ${
                  index < currentStep
                    ? 'bg-primary-600'
                    : index === currentStep
                    ? 'bg-primary-400'
                    : 'bg-gray-200'
                }`}
                aria-label={`${step.title}${index < currentStep ? ' (completed)' : index === currentStep ? ' (current)' : ''}`}
              />
            ))}
          </nav>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg" role="alert">
            {error}
          </div>
        )}

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 md:p-8">
          <CurrentStepComponent
            formData={formData}
            updateFormData={updateFormData}
          />
        </div>

        {/* Navigation */}
        <div className="mt-6 flex justify-between">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 0}
            className="btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>

          {currentStep === steps.length - 1 ? (
            <button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="btn-primary min-w-[140px]"
            >
              {isSubmitting ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  Submitting...
                </span>
              ) : (
                'Submit for Review'
              )}
            </button>
          ) : (
            <button onClick={handleNext} className="btn-primary">
              Next
            </button>
          )}
        </div>

        {/* HIPAA notice */}
        <p className="mt-4 text-xs text-center text-gray-500">
          All information entered is Protected Health Information (PHI) and is protected under HIPAA.
          This data is encrypted at rest and in transit.
        </p>
      </main>
    </div>
  );
}
