# Patient Case-Taking Software

HIPAA-compliant patient intake and clinical documentation system built with Next.js, NestJS, and PostgreSQL.

## Architecture

```
patient-case-taking-software/
├── packages/
│   ├── shared/          # Shared types, validators, constants (Zod + FHIR R4)
│   ├── backend/         # NestJS API server (TypeORM + PostgreSQL)
│   └── frontend/        # Next.js client (React + Tailwind CSS)
├── scripts/             # Database initialization scripts
├── docker-compose.yml   # Development environment
└── package.json         # Monorepo root
```

## Tech Stack

| Layer | Technology | Justification |
|-------|-----------|---------------|
| Frontend | Next.js 14, React 18, TypeScript | SSR, type safety, WCAG AA ready |
| Styling | Tailwind CSS | Responsive, high-contrast healthcare UI |
| Backend | NestJS, TypeORM | Enterprise modular structure, decorators |
| Database | PostgreSQL + pgcrypto | AES-256 encryption, JSONB for FHIR, RLS |
| Validation | Zod | Type-safe schema validation |
| Auth | JWT (15-min expiry) | HIPAA session timeout compliant |

## HIPAA Compliance Features

- **Encryption**: AES-256 at rest (pgcrypto), TLS 1.3 in transit
- **Audit Logging**: Immutable audit trail for every PHI access (DICOM ATNA format)
- **RBAC**: Fine-grained role-based access control with 7 role tiers
- **Session Management**: 15-minute JWT expiry, account lockout after failed attempts
- **Break-Glass**: Emergency access with mandatory justification and alerts
- **Data Retention**: Soft deletes with 7-year retention support
- **Security Headers**: CSP, HSTS, X-Frame-Options via Helmet

## Quick Start

### Prerequisites
- Node.js 20+
- PostgreSQL 16+
- Docker & Docker Compose (optional)

### Development Setup

```bash
# Install dependencies
npm install

# Set up environment
cp packages/backend/.env.example packages/backend/.env.development
# Edit .env.development with your database credentials

# Start database (Docker)
docker-compose up postgres redis -d

# Run migrations & seed
npm run db:migrate
npm run db:seed

# Start development servers
npm run dev
```

Frontend: http://localhost:3000
Backend API: http://localhost:3001/api/v1

### Docker Setup

```bash
docker-compose up
```

## API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/register` | Register new user |
| POST | `/api/v1/auth/login` | Login (returns JWT) |
| POST | `/api/v1/auth/break-glass` | Emergency access override |
| GET | `/api/v1/auth/me` | Get current user profile |

### Patients (PHI - all access audit-logged)
| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| POST | `/api/v1/patients` | Create patient | Intake, Clinician, Nurse, Admin |
| GET | `/api/v1/patients` | Search patients | All clinical roles |
| GET | `/api/v1/patients/:id` | Get patient by ID | All clinical roles |
| PUT | `/api/v1/patients/:id` | Update patient | All clinical roles |
| DELETE | `/api/v1/patients/:id` | Soft delete | Admin only |
| GET | `/api/v1/patients/:id/fhir` | FHIR R4 Patient resource | Clinician, Admin |

### Intake Forms
| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| POST | `/api/v1/intake` | Create intake form | Intake, Clinician, Patient |
| GET | `/api/v1/intake` | List intake forms | All clinical roles |
| GET | `/api/v1/intake/:id` | Get intake form | All clinical roles |
| PUT | `/api/v1/intake/:id` | Update form | Intake, Clinician, Patient |
| POST | `/api/v1/intake/:id/submit` | Submit for review | Intake, Patient |
| POST | `/api/v1/intake/:id/review` | Clinician review | Clinician, Admin |
| GET | `/api/v1/intake/completeness/:patientId` | Completeness score | Clinician, Admin |

### FHIR R4 Interoperability
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/fhir/encounter` | Create FHIR Encounter |
| GET | `/api/v1/fhir/encounter/:id` | Get FHIR Encounter |
| GET | `/api/v1/fhir/patient/:id/conditions` | Patient conditions (FHIR Bundle) |
| GET | `/api/v1/fhir/patient/:id/allergies` | Patient allergies (FHIR Bundle) |
| GET | `/api/v1/fhir/patient/:id/observations` | Patient observations (FHIR Bundle) |

### Audit Logs
| Method | Endpoint | Description | Roles |
|--------|----------|-------------|-------|
| GET | `/api/v1/audit` | Query audit logs | Compliance, Admin |
| GET | `/api/v1/audit/anomaly-stats` | Anomaly detection | Compliance, Admin |
| GET | `/api/v1/audit/bulk-access-check` | Bulk access detection | Compliance |
| GET | `/api/v1/audit/retention` | Retention statistics | Compliance, SysAdmin |

## User Roles & Permissions

| Role | Description | Key Permissions |
|------|-------------|-----------------|
| `patient` | Patient user | Read/update own profile, create intake |
| `intake_staff` | Front desk / intake | Read assigned patients, manage intake forms |
| `clinician` | Doctor / provider | Read all patients, update medical records |
| `nurse` | Nursing staff | Update vitals, create observations |
| `administrator` | Practice admin | Manage users, facility settings |
| `compliance_officer` | HIPAA compliance | Read/export audit logs |
| `system_admin` | Super admin | Full system access |

## Project Structure

### Backend (`packages/backend/`)
```
src/
├── modules/
│   ├── auth/           # Authentication, JWT, RBAC
│   │   ├── entities/   # User entity
│   │   ├── auth.service.ts
│   │   ├── auth.controller.ts
│   │   └── auth.module.ts
│   ├── patients/       # Patient CRUD with FHIR mapping
│   ├── intake/         # Intake form wizard backend
│   ├── audit/          # HIPAA immutable audit logging
│   └── fhir/           # FHIR R4 interoperability endpoints
├── common/
│   ├── guards/         # JWT auth, RBAC guards
│   ├── decorators/     # @Roles, @CurrentUser
│   └── interceptors/   # Audit logging interceptor
└── config/             # Database, environment config
```

### Frontend (`packages/frontend/`)
```
src/
├── app/
│   ├── (auth)/login/   # Login page
│   ├── (dashboard)/    # Dashboard
│   ├── (intake)/       # Intake wizard
│   └── page.tsx        # Landing page
├── components/
│   ├── intake/         # Wizard steps (HPI, ROS, Allergies, etc.)
│   ├── auth/           # Auth components
│   └── layout/         # Navigation, layout components
├── stores/             # Zustand state management
└── lib/                # API client, utilities
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DB_HOST` | Yes | PostgreSQL host |
| `DB_PORT` | Yes | PostgreSQL port |
| `DB_USERNAME` | Yes | Database user |
| `DB_PASSWORD` | Yes | Database password |
| `DB_NAME` | Yes | Database name |
| `JWT_SECRET` | Yes | JWT signing secret (64+ chars) |
| `JWT_REFRESH_SECRET` | Yes | Refresh token secret |
| `JWT_EXPIRATION` | No | Access token TTL (default: 15m) |
| `CORS_ORIGIN` | No | Allowed origin (default: localhost:3000) |

## License

Private - Healthcare use only. Requires signed BAAs before production deployment.
