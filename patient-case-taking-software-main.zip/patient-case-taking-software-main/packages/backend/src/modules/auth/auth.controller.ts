import {
  Controller,
  Post,
  Body,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
  Get,
} from '@nestjs/common';
import { Request } from 'express';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { CurrentUser } from '../../common/decorators/user.decorator';
import { loginSchema, userCreateSchema } from '@pct/shared';

/**
 * HIPAA § 164.312(a)(1): Access Control
 * Authentication controller handling login, registration, and session management.
 * All authentication events are audit-logged.
 */
@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  /**
   * POST /api/v1/auth/register
   * Register a new user account.
   */
  @Post('register')
  @HttpCode(HttpStatus.CREATED)
  async register(@Body() body: any, @Req() req: Request) {
    const validated = userCreateSchema.parse(body);

    return this.authService.register({
      email: validated.email,
      password: validated.password,
      firstName: validated.firstName,
      lastName: validated.lastName,
      role: validated.role as any,
      facilityId: validated.facilityId,
    });
  }

  /**
   * POST /api/v1/auth/login
   * Authenticate user with email/password.
   * Returns JWT access token (15 min) and refresh token.
   */
  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(
    @Body() body: any,
    @Req() req: Request
  ) {
    const validated = loginSchema.parse(body);

    const ipAddress =
      (req.headers['x-forwarded-for'] as string) ||
      req.socket?.remoteAddress ||
      'unknown';

    const userAgent = req.headers['user-agent'] || 'unknown';

    return this.authService.login(validated.email, validated.password, ipAddress, userAgent);
  }

  /**
   * POST /api/v1/auth/break-glass
   * HIPAA § 164.312(a)(2)(ii): Emergency Access Procedure
   * Break-glass access for clinical emergencies.
   */
  @Post('break-glass')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.OK)
  async breakGlass(
    @Body() body: { patientId: string; justification: string },
    @CurrentUser('id') userId: string,
    @Req() req: Request
  ) {
    return this.authService.breakGlassAccess(
      userId,
      body.patientId,
      body.justification
    );
  }

  /**
   * GET /api/v1/auth/me
   * Get current authenticated user profile.
   */
  @Get('me')
  @UseGuards(JwtAuthGuard)
  async getProfile(@CurrentUser() user: any) {
    const fullUser = await this.authService.validateUser(user.id);
    return {
      id: fullUser.id,
      email: fullUser.email,
      firstName: fullUser.firstName,
      lastName: fullUser.lastName,
      role: fullUser.role,
      facilityId: fullUser.facilityId,
      mfaEnabled: fullUser.mfaEnabled,
      isFirstLogin: fullUser.isFirstLogin,
    };
  }
}
