'use client';

import { useState } from 'react';

interface Props {
  formData: any;
  updateFormData: (section: string, data: any) => void;
}

/**
 * Allergies & Medication reconciliation step.
 * Critical safety information - displays prominently.
 */
export function IntakeStepAllergies({ formData, updateFormData }: Props) {
  const [substance, setSubstance] = useState('');
  const [reaction, setReaction] = useState('');
  const [severity, setSeverity] = useState<'mild' | 'moderate' | 'severe'>('mild');
  const [type, setType] = useState<'allergy' | 'intolerance'>('allergy');

  const allergies = formData.allergies || [];

  const addAllergy = () => {
    if (!substance.trim() || !reaction.trim()) return;
    updateFormData('allergies', [
      ...allergies,
      { substance: substance.trim(), reaction: reaction.trim(), severity, type },
    ]);
    setSubstance('');
    setReaction('');
    setSeverity('mild');
    setType('allergy');
  };

  const removeAllergy = (index: number) => {
    const updated = [...allergies];
    updated.splice(index, 1);
    updateFormData('allergies', updated);
  };

  const commonAllergies = [
    'Penicillin', 'Sulfa drugs', 'Aspirin', 'Ibuprofen', 'Latex',
    'Peanuts', 'Shellfish', 'Eggs', 'Milk', 'Soy', 'Wheat',
    'Codeine', 'Morphine', 'Iodine', 'Adhesive tape',
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Allergies & Adverse Reactions</h2>
        <p className="mt-1 text-gray-600">
          This is critical safety information. Please list all known allergies and adverse reactions.
        </p>
      </div>

      {/* Alert banner for severe allergies */}
      {allergies.some((a: any) => a.severity === 'severe') && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-lg">
          <div className="flex">
            <div className="ml-3">
              <p className="text-sm font-medium text-red-800">
                Severe Allergy Alert
              </p>
              <p className="mt-1 text-sm text-red-700">
                Patient has documented severe allergies. Verify before administering any medication.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Add allergy form */}
      <div className="bg-gray-50 rounded-lg p-4 border border-gray-200 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Allergen / Substance <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={substance}
              onChange={(e) => setSubstance(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="e.g., Penicillin, Peanuts"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Reaction <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={reaction}
              onChange={(e) => setReaction(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              placeholder="e.g., Hives, swelling, difficulty breathing"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
            <select
              value={type}
              onChange={(e) => setType(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="allergy">Allergy (immune response)</option>
              <option value="intolerance">Intolerance (non-immune)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Severity</label>
            <div className="flex gap-2">
              {(['mild', 'moderate', 'severe'] as const).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSeverity(s)}
                  className={`flex-1 px-3 py-2 text-sm rounded-lg border font-medium capitalize transition-colors ${
                    severity === s
                      ? s === 'severe'
                        ? 'bg-red-100 text-red-700 border-red-300'
                        : s === 'moderate'
                        ? 'bg-yellow-100 text-yellow-700 border-yellow-300'
                        : 'bg-green-100 text-green-700 border-green-300'
                      : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>

        <button onClick={addAllergy} className="btn-primary">
          Add Allergy
        </button>
      </div>

      {/* Common allergies quick-add */}
      <div>
        <p className="text-sm font-medium text-gray-700 mb-2">Quick Add Common Allergies:</p>
        <div className="flex flex-wrap gap-2">
          {commonAllergies.map((a) => (
            <button
              key={a}
              type="button"
              onClick={() => setSubstance(a)}
              className="px-3 py-1 text-xs bg-gray-100 text-gray-600 rounded-full hover:bg-gray-200 border border-gray-200"
            >
              {a}
            </button>
          ))}
        </div>
      </div>

      {/* Listed allergies */}
      {allergies.length > 0 && (
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">Documented Allergies ({allergies.length})</h3>
          <div className="space-y-2">
            {allergies.map((allergy: any, index: number) => (
              <div
                key={index}
                className={`flex items-center justify-between px-4 py-3 rounded-lg border ${
                  allergy.severity === 'severe'
                    ? 'bg-red-50 border-red-200'
                    : allergy.severity === 'moderate'
                    ? 'bg-yellow-50 border-yellow-200'
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`compliance-badge ${
                      allergy.severity === 'severe'
                        ? 'bg-red-200 text-red-800'
                        : allergy.severity === 'moderate'
                        ? 'bg-yellow-200 text-yellow-800'
                        : 'bg-green-200 text-green-800'
                    }`}
                  >
                    {allergy.severity.toUpperCase()}
                  </span>
                  <div>
                    <span className="font-medium">{allergy.substance}</span>
                    <span className="ml-2 text-sm text-gray-500">- {allergy.reaction}</span>
                    <span className="ml-2 text-xs text-gray-400 capitalize">({allergy.type})</span>
                  </div>
                </div>
                <button
                  onClick={() => removeAllergy(index)}
                  className="text-red-500 hover:text-red-700 text-sm"
                  aria-label={`Remove ${allergy.substance}`}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {allergies.length === 0 && (
        <div className="text-center py-6 text-gray-500 border-2 border-dashed border-gray-200 rounded-lg">
          <p className="font-medium">No allergies documented</p>
          <p className="text-sm mt-1">If you have no known allergies, please continue.</p>
        </div>
      )}
    </div>
  );
}
