import { z } from 'zod';

const nameSchema = z.object({
  family: z.string().min(1).max(100),
  given: z.array(z.string().min(1).max(50)).min(1),
  prefix: z.array(z.string()).optional(),
  suffix: z.array(z.string()).optional(),
});

const telecomSchema = z.object({
  system: z.enum(['phone', 'email', 'fax']),
  value: z.string().min(1),
  use: z.enum(['home', 'work', 'mobile', 'old']).optional(),
});

const addressSchema = z.object({
  use: z.enum(['home', 'work', 'old', 'temp']).optional(),
  line: z.array(z.string()).optional(),
  city: z.string().min(1).max(100),
  state: z.string().length(2),
  postalCode: z.string().regex(/^\d{5}(-\d{4})?$/),
  country: z.string().default('US'),
});

export const patientCreateSchema = z.object({
  identifier: z
    .array(
      z.object({
        system: z.string().url(),
        value: z.string().min(1),
      })
    )
    .optional(),
  name: z.array(nameSchema).min(1),
  gender: z.enum(['male', 'female', 'other', 'unknown']),
  birthDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  telecom: z.array(telecomSchema).min(1),
  address: z.array(addressSchema).min(1),
  contact: z
    .array(
      z.object({
        relationship: z
          .array(
            z.object({
              coding: z.array(
                z.object({
                  system: z.string(),
                  code: z.string(),
                })
              ),
            })
          )
          .optional(),
        name: nameSchema.optional(),
        telecom: z.array(telecomSchema).optional(),
      })
    )
    .optional(),
});

export const patientUpdateSchema = patientCreateSchema.partial();

export const intakeFormSchema = z.object({
  patientId: z.string().uuid(),
  chiefComplaint: z.string().min(1, 'Chief complaint is required').max(2000),
  hpi: z.object({
    onset: z.string().min(1),
    location: z.string().min(1),
    duration: z.string().min(1),
    character: z.string().min(1),
    aggravatingFactors: z.string(),
    relievingFactors: z.string(),
    timing: z.string(),
    severity: z.number().min(1).max(10),
    associatedSymptoms: z.array(z.string()),
  }),
  reviewOfSystems: z.record(z.array(z.string())),
  medicalHistory: z.object({
    conditions: z.array(
      z.object({
        name: z.string().min(1),
        icdCode: z.string().optional(),
        diagnosedDate: z.string().optional(),
      })
    ),
    surgeries: z.array(
      z.object({
        name: z.string().min(1),
        date: z.string().optional(),
        notes: z.string().optional(),
      })
    ),
    medications: z.array(
      z.object({
        name: z.string().min(1),
        dosage: z.string().min(1),
        frequency: z.string().min(1),
        rxnormCode: z.string().optional(),
      })
    ),
    familyHistory: z.array(
      z.object({
        condition: z.string().min(1),
        relation: z.string().min(1),
      })
    ),
  }),
  allergies: z.array(
    z.object({
      substance: z.string().min(1),
      reaction: z.string().min(1),
      severity: z.enum(['mild', 'moderate', 'severe']),
      type: z.enum(['allergy', 'intolerance']),
    })
  ),
  socialHistory: z.object({
    smokingStatus: z.string(),
    alcoholUse: z.string(),
    exerciseFrequency: z.string(),
    occupation: z.string(),
  }),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const userCreateSchema = z.object({
  email: z.string().email(),
  password: z
    .string()
    .min(12, 'Password must be at least 12 characters')
    .regex(/[A-Z]/, 'Must contain uppercase letter')
    .regex(/[a-z]/, 'Must contain lowercase letter')
    .regex(/[0-9]/, 'Must contain a number')
    .regex(/[^A-Za-z0-9]/, 'Must contain a special character'),
  firstName: z.string().min(1).max(100),
  lastName: z.string().min(1).max(100),
  role: z.enum([
    'patient',
    'intake_staff',
    'clinician',
    'nurse',
    'administrator',
    'compliance_officer',
    'system_admin',
  ]),
  facilityId: z.string().uuid().optional(),
});
