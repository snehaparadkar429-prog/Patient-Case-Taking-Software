import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { Request } from 'express';
import { FhirService } from './fhir.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/auth.decorators';
import { CurrentUser } from '../../common/decorators/user.decorator';
import { UserRole } from '@pct/shared';

/**
 * FHIR R4 compliant REST controller.
 * Provides standardized healthcare data APIs for EHR interoperability.
 */
@Controller('fhir')
@UseGuards(JwtAuthGuard, RolesGuard)
export class FhirController {
  constructor(private fhirService: FhirService) {}

  /**
   * POST /api/v1/fhir/encounter
   * Create a FHIR Encounter resource.
   */
  @Post('encounter')
  @Roles(UserRole.CLINICIAN, UserRole.NURSE, UserRole.INTAKE_STAFF)
  @HttpCode(HttpStatus.CREATED)
  async createEncounter(
    @Body() body: any,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const ipAddress = (req.headers['x-forwarded-for'] as string) || req.socket?.remoteAddress || 'unknown';
    return this.fhirService.createEncounter(body, userId, userRole, ipAddress);
  }

  /**
   * GET /api/v1/fhir/encounter/:id
   * Get a FHIR Encounter resource.
   */
  @Get('encounter/:id')
  @Roles(UserRole.CLINICIAN, UserRole.NURSE, UserRole.ADMINISTRATOR)
  async getEncounter(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const ipAddress = (req.headers['x-forwarded-for'] as string) || req.socket?.remoteAddress || 'unknown';
    return this.fhirService.getEncounter(id, userId, userRole, ipAddress);
  }

  /**
   * GET /api/v1/fhir/patient/:patientId/conditions
   * Get patient conditions as FHIR Bundle.
   */
  @Get('patient/:patientId/conditions')
  @Roles(UserRole.CLINICIAN, UserRole.NURSE, UserRole.ADMINISTRATOR)
  async getPatientConditions(@Param('patientId') patientId: string) {
    return this.fhirService.getPatientConditions(patientId);
  }

  /**
   * GET /api/v1/fhir/patient/:patientId/allergies
   * Get patient allergies as FHIR Bundle.
   */
  @Get('patient/:patientId/allergies')
  @Roles(UserRole.CLINICIAN, UserRole.NURSE, UserRole.ADMINISTRATOR)
  async getPatientAllergies(@Param('patientId') patientId: string) {
    return this.fhirService.getPatientAllergies(patientId);
  }

  /**
   * GET /api/v1/fhir/patient/:patientId/observations
   * Get patient observations as FHIR Bundle.
   */
  @Get('patient/:patientId/observations')
  @Roles(UserRole.CLINICIAN, UserRole.NURSE, UserRole.ADMINISTRATOR)
  async getPatientObservations(
    @Param('patientId') patientId: string,
    @Query('category') category?: string
  ) {
    return this.fhirService.getPatientObservations(patientId, category);
  }
}
