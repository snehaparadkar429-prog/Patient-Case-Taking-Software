import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { Request } from 'express';
import { PatientsService } from './patients.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/auth.decorators';
import { CurrentUser } from '../../common/decorators/user.decorator';
import { UserRole } from '@pct/shared';
import { patientCreateSchema, patientUpdateSchema } from '@pct/shared';

/**
 * HIPAA § 164.312(a)(1): Access Control
 * Patient controller with RBAC enforcement and audit logging.
 * All PHI access is logged automatically.
 */
@Controller('patients')
@UseGuards(JwtAuthGuard, RolesGuard)
export class PatientsController {
  constructor(private patientsService: PatientsService) {}

  private getClientInfo(req: Request) {
    return {
      ipAddress:
        (req.headers['x-forwarded-for'] as string) ||
        req.socket?.remoteAddress ||
        'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
    };
  }

  /**
   * POST /api/v1/patients
   * Create a new patient record.
   */
  @Post()
  @Roles(UserRole.INTAKE_STAFF, UserRole.CLINICIAN, UserRole.NURSE, UserRole.ADMINISTRATOR)
  @HttpCode(HttpStatus.CREATED)
  async create(
    @Body() body: any,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const validated = patientCreateSchema.parse(body);
    const { ipAddress } = this.getClientInfo(req);

    return this.patientsService.create(validated as any, userId, userRole, ipAddress);
  }

  /**
   * GET /api/v1/patients
   * Search patients with pagination.
   */
  @Get()
  @Roles(
    UserRole.INTAKE_STAFF,
    UserRole.CLINICIAN,
    UserRole.NURSE,
    UserRole.ADMINISTRATOR,
    UserRole.PATIENT
  )
  async findAll(
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Query('search') search?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string
  ) {
    return this.patientsService.findAll(userId, userRole, {
      search,
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 20,
    });
  }

  /**
   * GET /api/v1/patients/:id
   * Get patient by ID with access control.
   */
  @Get(':id')
  @Roles(
    UserRole.INTAKE_STAFF,
    UserRole.CLINICIAN,
    UserRole.NURSE,
    UserRole.ADMINISTRATOR,
    UserRole.PATIENT
  )
  async findOne(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const { ipAddress, userAgent } = this.getClientInfo(req);
    return this.patientsService.findOne(id, userId, userRole, ipAddress, userAgent);
  }

  /**
   * PUT /api/v1/patients/:id
   * Update patient record.
   */
  @Put(':id')
  @Roles(UserRole.INTAKE_STAFF, UserRole.CLINICIAN, UserRole.NURSE, UserRole.ADMINISTRATOR)
  async update(
    @Param('id') id: string,
    @Body() body: any,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const validated = patientUpdateSchema.parse(body);
    const { ipAddress } = this.getClientInfo(req);
    return this.patientsService.update(id, validated as any, userId, userRole, ipAddress);
  }

  /**
   * DELETE /api/v1/patients/:id
   * Soft delete patient record (admin only).
   */
  @Delete(':id')
  @Roles(UserRole.ADMINISTRATOR, UserRole.SYSTEM_ADMIN)
  @HttpCode(HttpStatus.NO_CONTENT)
  async remove(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const { ipAddress } = this.getClientInfo(req);
    await this.patientsService.remove(id, userId, userRole, ipAddress);
  }

  /**
   * GET /api/v1/patients/:id/fhir
   * Get patient as FHIR R4 resource for interoperability.
   */
  @Get(':id/fhir')
  @Roles(UserRole.CLINICIAN, UserRole.NURSE, UserRole.ADMINISTRATOR, UserRole.SYSTEM_ADMIN)
  async getFhirResource(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const { ipAddress } = this.getClientInfo(req);
    return this.patientsService.getFhirResource(id, userId, userRole, ipAddress);
  }
}
