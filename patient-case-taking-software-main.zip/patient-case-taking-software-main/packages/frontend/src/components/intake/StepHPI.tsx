'use client';

interface Props {
  formData: any;
  updateFormData: (section: string, data: any) => void;
}

/**
 * INT-02: History of Present Illness (HPI) Builder
 * Uses OPQRST format for structured clinical documentation:
 * - Onset, Provocation/Palliation, Quality, Region/Radiation,
 *   Severity, Timing
 */
export function IntakeStepHPI({ formData, updateFormData }: Props) {
  const hpi = formData.hpi;

  const updateHpi = (field: string, value: any) => {
    updateFormData('hpi', { ...hpi, [field]: value });
  };

  const commonSymptoms = [
    'Nausea', 'Vomiting', 'Dizziness', 'Fever', 'Chills', 'Sweating',
    'Weight loss', 'Weight gain', 'Insomnia', 'Numbness', 'Tingling',
    'Weakness', 'Blurred vision', 'Loss of appetite', 'Constipation',
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">History of Present Illness</h2>
        <p className="mt-1 text-gray-600">
          Please provide detailed information about your current symptoms using the OPQRST format.
        </p>
      </div>

      {/* Severity slider */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Pain/Symptom Severity <span className="text-red-500">*</span>
        </label>
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-500">1 (Mild)</span>
          <input
            type="range"
            min="1"
            max="10"
            value={hpi.severity}
            onChange={(e) => updateHpi('severity', parseInt(e.target.value))}
            className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            aria-label="Pain severity level"
          />
          <span className="text-sm text-gray-500">10 (Severe)</span>
          <span
            className={`inline-flex items-center justify-center w-10 h-10 rounded-full text-white font-bold text-sm ${
              hpi.severity <= 3
                ? 'bg-green-500'
                : hpi.severity <= 6
                ? 'bg-yellow-500'
                : 'bg-red-500'
            }`}
          >
            {hpi.severity}
          </span>
        </div>
      </div>

      {/* OPQRST fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="onset" className="block text-sm font-medium text-gray-700 mb-1">
            <span className="font-bold">O</span>nset - When did it start? <span className="text-red-500">*</span>
          </label>
          <input
            id="onset"
            type="text"
            value={hpi.onset}
            onChange={(e) => updateHpi('onset', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder="e.g., 3 days ago, last Tuesday morning"
          />
        </div>

        <div>
          <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
            <span className="font-bold">R</span>egion - Where is it located? <span className="text-red-500">*</span>
          </label>
          <input
            id="location"
            type="text"
            value={hpi.location}
            onChange={(e) => updateHpi('location', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder="e.g., Right side of head, behind left eye"
          />
        </div>

        <div>
          <label htmlFor="duration" className="block text-sm font-medium text-gray-700 mb-1">
            <span className="font-bold">D</span>uration - How long does it last? <span className="text-red-500">*</span>
          </label>
          <input
            id="duration"
            type="text"
            value={hpi.duration}
            onChange={(e) => updateHpi('duration', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder="e.g., Constant, 2-3 hours at a time"
          />
        </div>

        <div>
          <label htmlFor="character" className="block text-sm font-medium text-gray-700 mb-1">
            <span className="font-bold">Q</span>uality - What does it feel like? <span className="text-red-500">*</span>
          </label>
          <input
            id="character"
            type="text"
            value={hpi.character}
            onChange={(e) => updateHpi('character', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder="e.g., Sharp, throbbing, dull, burning"
          />
        </div>

        <div>
          <label htmlFor="timing" className="block text-sm font-medium text-gray-700 mb-1">
            <span className="font-bold">T</span>iming - When does it occur?
          </label>
          <input
            id="timing"
            type="text"
            value={hpi.timing}
            onChange={(e) => updateHpi('timing', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder="e.g., Worse in the morning, after meals"
          />
        </div>

        <div>
          <label htmlFor="aggravating" className="block text-sm font-medium text-gray-700 mb-1">
            <span className="font-bold">P</span>rovocation - What makes it worse?
          </label>
          <input
            id="aggravating"
            type="text"
            value={hpi.aggravatingFactors}
            onChange={(e) => updateHpi('aggravatingFactors', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder="e.g., Light, noise, movement, bending over"
          />
        </div>

        <div className="md:col-span-2">
          <label htmlFor="relieving" className="block text-sm font-medium text-gray-700 mb-1">
            <span className="font-bold">P</span>alliation - What makes it better?
          </label>
          <input
            id="relieving"
            type="text"
            value={hpi.relievingFactors}
            onChange={(e) => updateHpi('relievingFactors', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            placeholder="e.g., Rest, dark room, medication, ice pack"
          />
        </div>
      </div>

      {/* Associated Symptoms */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Associated Symptoms (select all that apply)
        </label>
        <div className="flex flex-wrap gap-2">
          {commonSymptoms.map((symptom) => {
            const isSelected = hpi.associatedSymptoms.includes(symptom.toLowerCase());
            return (
              <button
                key={symptom}
                type="button"
                onClick={() => {
                  const updated = isSelected
                    ? hpi.associatedSymptoms.filter((s: string) => s !== symptom.toLowerCase())
                    : [...hpi.associatedSymptoms, symptom.toLowerCase()];
                  updateHpi('associatedSymptoms', updated);
                }}
                className={`px-3 py-1.5 text-sm rounded-full border transition-colors ${
                  isSelected
                    ? 'bg-primary-100 text-primary-700 border-primary-300'
                    : 'bg-gray-50 text-gray-600 border-gray-200 hover:bg-gray-100'
                }`}
              >
                {symptom}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
