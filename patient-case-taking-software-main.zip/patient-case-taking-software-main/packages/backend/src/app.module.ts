import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './modules/auth/auth.module';
import { PatientsModule } from './modules/patients/patients.module';
import { IntakeModule } from './modules/intake/intake.module';
import { AuditModule } from './modules/audit/audit.module';
import { FhirModule } from './modules/fhir/fhir.module';
import { databaseConfig } from './config/database.config';

@Module({
  imports: [
    // Environment configuration - no hardcoded secrets
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: `.env.${process.env.NODE_ENV || 'development'}`,
    }),

    // PostgreSQL with encryption at rest via pgcrypto
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => databaseConfig(config),
    }),

    // Feature modules
    AuthModule,
    PatientsModule,
    IntakeModule,
    AuditModule,
    FhirModule,
  ],
})
export class AppModule {}
