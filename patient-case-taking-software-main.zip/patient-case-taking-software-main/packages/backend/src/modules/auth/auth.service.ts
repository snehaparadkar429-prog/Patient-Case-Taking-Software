import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  BadRequestException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, IsNull } from 'typeorm';
import * as bcrypt from 'bcryptjs';
import { User } from './entities/user.entity';
import { UserRole, HIPAA_CONFIG } from '@pct/shared';

export interface JwtPayload {
  sub: string;
  email: string;
  role: UserRole;
  facilityId?: string;
  sessionId: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: string;
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    role: UserRole;
  };
}

/**
 * HIPAA § 164.312(a)(1): Access Control
 * HIPAA § 164.312(d): Person or Entity Authentication
 *
 * This service handles:
 * - User registration with strong password enforcement
 * - Authentication via email/password
 * - JWT token generation with 15-minute expiry
 * - Account lockout after failed attempts
 * - Break-glass emergency access
 */
@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
    private jwtService: JwtService,
    private configService: ConfigService
  ) {}

  /**
   * Register a new user account.
   * Enforces HIPAA password requirements (12+ chars, complexity).
   */
  async register(dto: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    role: UserRole;
    facilityId?: string;
  }): Promise<AuthTokens> {
    // Check for existing user
    const existing = await this.userRepository.findOne({
      where: { email: dto.email.toLowerCase() },
    });

    if (existing) {
      throw new ConflictException('An account with this email already exists');
    }

    // HIPAA: Enforce strong password policy
    if (dto.password.length < HIPAA_CONFIG.PASSWORD_MIN_LENGTH) {
      throw new BadRequestException(
        `Password must be at least ${HIPAA_CONFIG.PASSWORD_MIN_LENGTH} characters`
      );
    }

    // Hash password with bcrypt (cost factor 12)
    const passwordHash = await bcrypt.hash(dto.password, 12);

    const user = this.userRepository.create({
      email: dto.email.toLowerCase(),
      passwordHash,
      firstName: dto.firstName,
      lastName: dto.lastName,
      role: dto.role,
      facilityId: dto.facilityId,
      isFirstLogin: true,
    });

    const saved = await this.userRepository.save(user);

    return this.generateTokens(saved);
  }

  /**
   * Authenticate user with email/password.
   * Implements account lockout after max failed attempts.
   */
  async login(
    email: string,
    password: string,
    ipAddress: string,
    userAgent: string
  ): Promise<AuthTokens> {
    const user = await this.userRepository
      .createQueryBuilder('user')
      .addSelect('user.passwordHash')
      .where('user.email = :email', { email: email.toLowerCase() })
      .andWhere('user.deletedAt IS NULL')
      .getOne();

    if (!user) {
      // HIPAA: Generic error message to prevent user enumeration
      throw new UnauthorizedException('Invalid email or password');
    }

    // Check account lockout
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const lockMinutes = Math.ceil(
        (user.lockedUntil.getTime() - Date.now()) / 60000
      );
      throw new UnauthorizedException(
        `Account is locked. Try again in ${lockMinutes} minutes`
      );
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);

    if (!isPasswordValid) {
      const attempts = user.failedLoginAttempts + 1;

      if (attempts >= HIPAA_CONFIG.MAX_LOGIN_ATTEMPTS) {
        // Lock the account
        user.lockedUntil = new Date(
          Date.now() + HIPAA_CONFIG.LOCKOUT_DURATION_MS
        );
        user.failedLoginAttempts = attempts;
        await this.userRepository.save(user);

        throw new UnauthorizedException(
          'Account locked due to too many failed attempts. Please contact your administrator.'
        );
      }

      user.failedLoginAttempts = attempts;
      await this.userRepository.save(user);

      throw new UnauthorizedException('Invalid email or password');
    }

    // Check if account is active
    if (!user.isActive) {
      throw new UnauthorizedException('Account has been deactivated');
    }

    // Reset failed attempts on successful login
    user.failedLoginAttempts = 0;
    user.lockedUntil = null;
    await this.userRepository.save(user);

    return this.generateTokens(user);
  }

  /**
   * HIPAA § 164.312(a)(2)(ii): Emergency Access Procedure
   * Break-glass access for emergency situations.
   * Triggers alerts and mandatory audit logging.
   */
  async breakGlassAccess(
    clinicianId: string,
    patientId: string,
    justification: string
  ): Promise<{ accessGranted: boolean; emergencyToken: string }> {
    const clinician = await this.userRepository.findOne({
      where: { id: clinicianId },
    });

    if (!clinician) {
      throw new UnauthorizedException('Clinician not found');
    }

    if (
      clinician.role !== UserRole.CLINICIAN &&
      clinician.role !== UserRole.NURSE
    ) {
      throw new UnauthorizedException(
        'Break-glass access is only available to clinical staff'
      );
    }

    if (!justification || justification.length < 10) {
      throw new BadRequestException(
        'Break-glass justification must be at least 10 characters'
      );
    }

    // Generate short-lived emergency token (5 minutes)
    const emergencyToken = await this.jwtService.signAsync(
      {
        sub: clinicianId,
        email: clinician.email,
        role: clinician.role,
        sessionId: `breakglass_${Date.now()}`,
        breakGlass: true,
        patientId,
      },
      {
        secret: this.configService.get<string>('JWT_SECRET'),
        expiresIn: '5m',
      }
    );

    return {
      accessGranted: true,
      emergencyToken,
    };
  }

  /**
   * Validate user exists and is active (for token refresh).
   */
  async validateUser(userId: string): Promise<User> {
    const user = await this.userRepository.findOne({
      where: { id: userId, isActive: true, deletedAt: IsNull() },
    });

    if (!user) {
      throw new UnauthorizedException('User not found or inactive');
    }

    return user;
  }

  /**
   * Generate JWT access and refresh tokens.
   * Access token expires in 15 minutes (HIPAA session timeout).
   */
  private async generateTokens(user: User): Promise<AuthTokens> {
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2)}`;

    const payload: JwtPayload = {
      sub: user.id,
      email: user.email,
      role: user.role,
      facilityId: user.facilityId,
      sessionId,
    };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwtService.signAsync(payload, {
        secret: this.configService.get<string>('JWT_SECRET'),
        expiresIn: this.configService.get<string>('JWT_EXPIRATION', '15m'),
      }),
      this.jwtService.signAsync(
        { sub: user.id, sessionId },
        {
          secret: this.configService.get<string>('JWT_REFRESH_SECRET'),
          expiresIn: this.configService.get<string>(
            'JWT_REFRESH_EXPIRATION',
            '7d'
          ),
        }
      ),
    ]);

    return {
      accessToken,
      refreshToken,
      expiresIn: this.configService.get<string>('JWT_EXPIRATION', '15m'),
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
      },
    };
  }
}
