import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { Request } from 'express';
import { IntakeService } from './intake.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/auth.decorators';
import { CurrentUser } from '../../common/decorators/user.decorator';
import { UserRole, IntakeStatus } from '@pct/shared';
import { intakeFormSchema } from '@pct/shared';

/**
 * Intake Form controller managing clinical documentation workflow.
 * All PHI access is audit-logged via the service layer.
 */
@Controller('intake')
@UseGuards(JwtAuthGuard, RolesGuard)
export class IntakeController {
  constructor(private intakeService: IntakeService) {}

  /**
   * POST /api/v1/intake
   * Create a new intake form.
   */
  @Post()
  @Roles(UserRole.INTAKE_STAFF, UserRole.CLINICIAN, UserRole.PATIENT)
  @HttpCode(HttpStatus.CREATED)
  async create(
    @Body() body: any,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const validated = intakeFormSchema.parse(body);
    const ipAddress = (req.headers['x-forwarded-for'] as string) || req.socket?.remoteAddress || 'unknown';

    return this.intakeService.create(validated as any, userId, userRole, ipAddress);
  }

  /**
   * GET /api/v1/intake
   * List intake forms with filters.
   */
  @Get()
  @Roles(
    UserRole.INTAKE_STAFF,
    UserRole.CLINICIAN,
    UserRole.NURSE,
    UserRole.ADMINISTRATOR,
    UserRole.PATIENT
  )
  async findAll(
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Query('patientId') patientId?: string,
    @Query('status') status?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string
  ) {
    return this.intakeService.findAll(userId, userRole, {
      patientId,
      status: status as IntakeStatus,
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 20,
    });
  }

  /**
   * GET /api/v1/intake/:id
   * Get intake form by ID.
   */
  @Get(':id')
  @Roles(
    UserRole.INTAKE_STAFF,
    UserRole.CLINICIAN,
    UserRole.NURSE,
    UserRole.ADMINISTRATOR,
    UserRole.PATIENT
  )
  async findOne(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const ipAddress = (req.headers['x-forwarded-for'] as string) || req.socket?.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    return this.intakeService.findOne(id, userId, userRole, ipAddress, userAgent);
  }

  /**
   * PUT /api/v1/intake/:id
   * Update intake form.
   */
  @Put(':id')
  @Roles(UserRole.INTAKE_STAFF, UserRole.CLINICIAN, UserRole.PATIENT)
  async update(
    @Param('id') id: string,
    @Body() body: any,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const ipAddress = (req.headers['x-forwarded-for'] as string) || req.socket?.remoteAddress || 'unknown';
    return this.intakeService.update(id, body, userId, userRole, ipAddress);
  }

  /**
   * POST /api/v1/intake/:id/submit
   * Submit completed intake form for review.
   */
  @Post(':id/submit')
  @Roles(UserRole.INTAKE_STAFF, UserRole.PATIENT)
  @HttpCode(HttpStatus.OK)
  async submit(
    @Param('id') id: string,
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const ipAddress = (req.headers['x-forwarded-for'] as string) || req.socket?.remoteAddress || 'unknown';
    return this.intakeService.submit(id, userId, userRole, ipAddress);
  }

  /**
   * POST /api/v1/intake/:id/review
   * Clinician review of intake form.
   */
  @Post(':id/review')
  @Roles(UserRole.CLINICIAN, UserRole.ADMINISTRATOR)
  @HttpCode(HttpStatus.OK)
  async review(
    @Param('id') id: string,
    @Body() body: { reviewNotes: string; approve: boolean },
    @CurrentUser('id') userId: string,
    @CurrentUser('role') userRole: UserRole,
    @Req() req: Request
  ) {
    const ipAddress = (req.headers['x-forwarded-for'] as string) || req.socket?.remoteAddress || 'unknown';
    return this.intakeService.review(
      id,
      body.reviewNotes,
      userId,
      userRole,
      ipAddress,
      body.approve
    );
  }

  /**
   * GET /api/v1/intake/completeness/:patientId
   * REP-02: Clinical Completeness Scorecard.
   */
  @Get('completeness/:patientId')
  @Roles(UserRole.CLINICIAN, UserRole.ADMINISTRATOR)
  async getCompleteness(@Param('patientId') patientId: string) {
    return this.intakeService.getCompletenessStats(patientId);
  }
}
