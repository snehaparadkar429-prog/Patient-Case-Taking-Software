'use client';

import { useState } from 'react';

interface Props {
  formData: any;
  updateFormData: (section: string, data: any) => void;
}

/**
 * INT-02: Review of Systems (ROS)
 * Systematic review of body systems for symptom identification.
 */
export function IntakeStepROS({ formData, updateFormData }: Props) {
  const [selectedSystem, setSelectedSystem] = useState<string | null>(null);

  const systems = [
    {
      id: 'constitutional',
      name: 'Constitutional',
      symptoms: ['Fever', 'Chills', 'Night sweats', 'Weight loss', 'Weight gain', 'Fatigue', 'Malaise'],
    },
    {
      id: 'heent',
      name: 'HEENT',
      symptoms: ['Headache', 'Vision changes', 'Hearing loss', 'Ear pain', 'Sore throat', 'Nasal congestion', 'Tooth pain'],
    },
    {
      id: 'cardiovascular',
      name: 'Cardiovascular',
      symptoms: ['Chest pain', 'Palpitations', 'Shortness of breath', 'Orthopnea', 'Edema', 'Claudication'],
    },
    {
      id: 'respiratory',
      name: 'Respiratory',
      symptoms: ['Cough', 'Wheezing', 'Shortness of breath', 'Hemoptysis', 'Sputum production'],
    },
    {
      id: 'gastrointestinal',
      name: 'Gastrointestinal',
      symptoms: ['Nausea', 'Vomiting', 'Diarrhea', 'Constipation', 'Abdominal pain', 'Heartburn', 'Blood in stool'],
    },
    {
      id: 'genitourinary',
      name: 'Genitourinary',
      symptoms: ['Dysuria', 'Frequency', 'Urgency', 'Hematuria', 'Incontinence'],
    },
    {
      id: 'musculoskeletal',
      name: 'Musculoskeletal',
      symptoms: ['Joint pain', 'Back pain', 'Stiffness', 'Swelling', 'Limited range of motion', 'Muscle weakness'],
    },
    {
      id: 'neurological',
      name: 'Neurological',
      symptoms: ['Dizziness', 'Numbness', 'Tingling', 'Seizures', 'Loss of consciousness', 'Memory changes'],
    },
    {
      id: 'psychiatric',
      name: 'Psychiatric',
      symptoms: ['Depression', 'Anxiety', 'Insomnia', 'Changes in mood', 'Suicidal ideation', 'Hallucinations'],
    },
    {
      id: 'skin',
      name: 'Skin',
      symptoms: ['Rash', 'Lesions', 'Itching', 'Color changes', 'Hair loss', 'Nail changes'],
    },
  ];

  const ros = formData.reviewOfSystems || {};

  const toggleSymptom = (systemId: string, symptom: string) => {
    const currentSymptoms = ros[systemId] || [];
    const normalized = symptom.toLowerCase();
    const updated = currentSymptoms.includes(normalized)
      ? currentSymptoms.filter((s: string) => s !== normalized)
      : [...currentSymptoms, normalized];

    updateFormData('reviewOfSystems', {
      ...ros,
      [systemId]: updated,
    });
  };

  const getSystemCount = (systemId: string) => {
    return (ros[systemId] || []).length;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Review of Systems</h2>
        <p className="mt-1 text-gray-600">
          Select any symptoms you are currently experiencing from each body system.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* System list */}
        <div className="md:col-span-1 space-y-2">
          {systems.map((system) => {
            const count = getSystemCount(system.id);
            return (
              <button
                key={system.id}
                onClick={() => setSelectedSystem(system.id)}
                className={`w-full text-left px-4 py-3 rounded-lg border transition-colors ${
                  selectedSystem === system.id
                    ? 'bg-primary-50 border-primary-300 text-primary-700'
                    : 'bg-white border-gray-200 hover:bg-gray-50'
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-medium text-sm">{system.name}</span>
                  {count > 0 && (
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary-100 text-primary-700 text-xs font-medium">
                      {count}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Symptoms for selected system */}
        <div className="md:col-span-2">
          {selectedSystem ? (
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <h3 className="font-semibold text-gray-900 mb-3">
                {systems.find((s) => s.id === selectedSystem)?.name} Symptoms
              </h3>
              <div className="flex flex-wrap gap-2">
                {systems
                  .find((s) => s.id === selectedSystem)
                  ?.symptoms.map((symptom) => {
                    const isSelected = (ros[selectedSystem] || []).includes(symptom.toLowerCase());
                    return (
                      <button
                        key={symptom}
                        onClick={() => toggleSymptom(selectedSystem, symptom)}
                        className={`px-3 py-2 text-sm rounded-lg border transition-colors ${
                          isSelected
                            ? 'bg-primary-100 text-primary-700 border-primary-300 font-medium'
                            : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-100'
                        }`}
                      >
                        {isSelected && '✓ '}{symptom}
                      </button>
                    );
                  })}
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 rounded-lg p-8 border border-gray-200 text-center text-gray-500">
              <p>Select a body system from the left to view symptoms</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
