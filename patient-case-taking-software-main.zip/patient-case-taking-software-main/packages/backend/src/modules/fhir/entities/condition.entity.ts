import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { Patient } from '../../patients/entities/patient.entity';

@Entity('conditions')
@Index(['patientId'])
@Index(['code'])
export class Condition {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  patientId: string;

  @ManyToOne(() => Patient)
  @JoinColumn({ name: 'patientId' })
  patient: Patient;

  // FHIR Condition.clinicalStatus
  @Column({ type: 'simple-json' })
  clinicalStatus: { coding: Array<{ system: string; code: string }> };

  // FHIR Condition.verificationStatus
  @Column({ type: 'simple-json' })
  verificationStatus: { coding: Array<{ system: string; code: string }> };

  // FHIR Condition.code (ICD-10-CM / SNOMED-CT)
  @Column({ type: 'simple-json' })
  code: { coding: Array<{ system: string; code: string; display?: string }> };

  // FHIR Condition.category
  @Column({ type: 'simple-json', nullable: true })
  category: Array<{ coding: Array<{ system: string; code: string }> }>;

  @Column({ type: 'datetime', nullable: true })
  onsetDateTime: Date;

  @Column({ type: 'datetime', nullable: true })
  abatementDateTime: Date;

  @Column({ type: 'text', nullable: true })
  encounterId: string;

  @CreateDateColumn()
  createdAt: Date;
}
