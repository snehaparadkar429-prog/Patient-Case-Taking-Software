'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuthStore } from '@/stores/auth.store';
import { api } from '@/lib/api';

export default function DashboardPage() {
  const { user, isAuthenticated, isLoading, loadUser, logout } = useAuthStore();
  const [patients, setPatients] = useState<any[]>([]);
  const [intakeForms, setIntakeForms] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
      return;
    }

    if (isAuthenticated) {
      Promise.all([
        api.getPatients({ limit: 10 }).catch(() => ({ patients: [] })),
        api.getIntakeForms({ limit: 10 }).catch(() => ({ forms: [] })),
      ]).then(([patientsRes, formsRes]) => {
        setPatients(patientsRes.patients || []);
        setIntakeForms(formsRes.forms || []);
        setLoading(false);
      });
    }
  }, [isAuthenticated, isLoading, router]);

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  if (isLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-8">
              <Link href="/dashboard" className="text-lg font-bold text-primary-600">
                PCT Software
              </Link>
              <Link href="/dashboard" className="text-sm text-gray-700 hover:text-primary-600">
                Dashboard
              </Link>
              <Link href="/intake" className="text-sm text-gray-700 hover:text-primary-600">
                New Intake
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-gray-600">
                <span className="font-medium">{user?.firstName} {user?.lastName}</span>
                <span className="ml-2 px-2 py-0.5 bg-primary-100 text-primary-700 rounded-full text-xs capitalize">
                  {user?.role?.replace('_', ' ')}
                </span>
              </div>
              <button
                onClick={handleLogout}
                className="text-sm text-gray-500 hover:text-red-600"
              >
                Sign out
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h1>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="text-sm text-gray-500">Total Patients</div>
            <div className="text-2xl font-bold text-gray-900">{patients.length}</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="text-sm text-gray-500">Intake Forms</div>
            <div className="text-2xl font-bold text-gray-900">{intakeForms.length}</div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="text-sm text-gray-500">Pending Review</div>
            <div className="text-2xl font-bold text-yellow-600">
              {intakeForms.filter((f) => f.status === 'completed').length}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="text-sm text-gray-500">Completed</div>
            <div className="text-2xl font-bold text-green-600">
              {intakeForms.filter((f) => f.status === 'reviewed').length}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <Link
                href="/intake"
                className="block w-full btn-primary text-center"
              >
                New Patient Intake
              </Link>
              <Link
                href="/patients"
                className="block w-full btn-secondary text-center"
              >
                View All Patients
              </Link>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Intake Forms</h2>
            {intakeForms.length === 0 ? (
              <p className="text-sm text-gray-500">No intake forms yet.</p>
            ) : (
              <div className="space-y-2">
                {intakeForms.slice(0, 5).map((form) => (
                  <div
                    key={form.id}
                    className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0"
                  >
                    <div>
                      <p className="text-sm font-medium text-gray-900 truncate max-w-[200px]">
                        {form.chiefComplaint || 'Untitled'}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(form.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <span
                      className={`compliance-badge ${
                        form.status === 'reviewed'
                          ? 'bg-green-100 text-green-800'
                          : form.status === 'completed'
                          ? 'bg-blue-100 text-blue-800'
                          : form.status === 'in_progress'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {form.status?.replace('_', ' ')}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
