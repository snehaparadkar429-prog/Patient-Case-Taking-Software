-- HIPAA § 164.312(e)(1): Encryption at Rest
-- Enable pgcrypto extension for AES-256 column-level encryption
-- and cryptographic functions for audit integrity

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create application schema for logical separation
CREATE SCHEMA IF NOT EXISTS phi;  -- Protected Health Information
CREATE SCHEMA IF NOT EXISTS audit; -- Audit logs (append-only)
CREATE SCHEMA IF NOT EXISTS auth;  -- Authentication & authorization

-- Enable Row Level Security for multi-tenant isolation (Phase 3)
-- ALTER TABLE phi.patients ENABLE ROW LEVEL SECURITY;

-- Create audit log partitioning function for performance
-- (Production: partition by month for archival)
