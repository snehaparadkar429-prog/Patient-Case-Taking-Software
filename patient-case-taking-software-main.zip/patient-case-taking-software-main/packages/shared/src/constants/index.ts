export const HIPAA_CONFIG = {
  SESSION_TIMEOUT_MS: 15 * 60 * 1000, // 15 minutes
  MAX_LOGIN_ATTEMPTS: 5,
  LOCKOUT_DURATION_MS: 30 * 60 * 1000, // 30 minutes
  PASSWORD_MIN_LENGTH: 12,
  PASSWORD_REQUIREMENTS: {
    uppercase: true,
    lowercase: true,
    numbers: true,
    specialChars: true,
  },
  PHI_RETENTION_DAYS: 2555, // ~7 years
  AUDIT_LOG_RETENTION_DAYS: 2555,
  BREAK_GLASS_ALERT_EMAILS: ['compliance@hospital.org', 'security@hospital.org'],
} as const;

export const FHIR_SYSTEMS = {
  ICD10: 'http://hl7.org/fhir/sid/icd-10-cm',
  SNOMED: 'http://snomed.info/sct',
  RXNORM: 'http://www.nlm.nih.gov/research/umls/rxnorm',
  LOINC: 'http://loinc.org',
  NPI: 'http://hl7.org/fhir/sid/us-npi',
} as const;

export const RBAC_PERMISSIONS = {
  patient: ['read:own_profile', 'update:own_profile', 'create:intake_form'],
  intake_staff: [
    'read:assigned_patients',
    'create:intake_form',
    'update:intake_form',
    'read:audit_logs',
  ],
  clinician: [
    'read:assigned_patients',
    'read:all_patients',
    'update:medical_records',
    'create:encounter',
    'read:audit_logs',
  ],
  nurse: [
    'read:assigned_patients',
    'update:vitals',
    'create:observation',
    'read:audit_logs',
  ],
  administrator: [
    'read:all_patients',
    'manage:users',
    'manage:facility_settings',
    'read:audit_logs',
    'read:reports',
  ],
  compliance_officer: [
    'read:audit_logs',
    'read:all_patients',
    'export:audit_logs',
    'manage:compliance_settings',
  ],
  system_admin: ['*'],
} as const;

export const AUDIT_EVENT_TYPES = {
  PHI_ACCESS: 'phi_access',
  PHI_CREATE: 'phi_create',
  PHI_UPDATE: 'phi_update',
  PHI_DELETE: 'phi_delete',
  PHI_EXPORT: 'phi_export',
  AUTH_LOGIN: 'auth_login',
  AUTH_LOGOUT: 'auth_logout',
  AUTH_FAILED: 'auth_failed',
  BREAK_GLASS: 'break_glass',
  CONSENT_GIVEN: 'consent_given',
  CONSENT_REVOKED: 'consent_revoked',
} as const;
