import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { Patient } from '../../patients/entities/patient.entity';

@Entity('allergy_intolerances')
@Index(['patientId'])
@Index(['code'])
export class AllergyIntolerance {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  patientId: string;

  @ManyToOne(() => Patient)
  @JoinColumn({ name: 'patientId' })
  patient: Patient;

  // FHIR AllergyIntolerance.clinicalStatus
  @Column({ type: 'simple-json' })
  clinicalStatus: { coding: Array<{ system: string; code: string }> };

  // FHIR AllergyIntolerance.verificationStatus
  @Column({ type: 'simple-json' })
  verificationStatus: { coding: Array<{ system: string; code: string }> };

  // FHIR AllergyIntolerance.type (allergy | intolerance)
  @Column({ length: 50, default: 'allergy' })
  type: string;

  // FHIR AllergyIntolerance.category
  @Column('simple-array', { nullable: true })
  category: string[];

  // FHIR AllergyIntolerance.criticality
  @Column({ length: 50, nullable: true })
  criticality: string;

  // FHIR AllergyIntolerance.code (SNOMED-CT / RxNorm)
  @Column({ type: 'simple-json' })
  code: { coding: Array<{ system: string; code: string; display?: string }> };

  // FHIR AllergyIntolerance.reaction
  @Column({ type: 'simple-json', nullable: true })
  reaction: Array<{
    substance?: { coding: Array<{ system: string; code: string; display?: string }> };
    manifestation: Array<{ coding: Array<{ system: string; code: string; display?: string }> }>;
    severity?: string;
  }>;

  @Column({ type: 'text', nullable: true })
  encounterId: string;

  @CreateDateColumn()
  createdAt: Date;
}
