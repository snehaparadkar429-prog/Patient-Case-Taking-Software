import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { IntakeStatus } from '@pct/shared';
import { Patient } from '../../patients/entities/patient.entity';
import { User } from '../../auth/entities/user.entity';

/**
 * HIPAA § 164.312(a)(1): Access Control
 * Intake form entity storing structured clinical documentation.
 * Contains HPI, ROS, Medical History, Allergies - all PHI.
 *
 * Each form is tied to a patient encounter for complete audit trail.
 */
@Entity('intake_forms')
@Index(['patientId', 'status'])
@Index(['createdAt'])
export class IntakeForm {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // Patient reference - this form's PHI subject
  @Column({ type: 'text' })
  patientId: string;

  @ManyToOne(() => Patient, { eager: false })
  @JoinColumn({ name: 'patientId' })
  patient: Patient;

  // Encounter reference
  @Column({ type: 'text', nullable: true })
  encounterId: string;

  // Status tracking
  @Column({ type: 'simple-enum', enum: IntakeStatus, default: IntakeStatus.DRAFT })
  status: IntakeStatus;

  // Chief Complaint
  @Column({ type: 'text' })
  chiefComplaint: string;

  // History of Present Illness (HPI) - structured per OPQRST format
  @Column({ type: 'simple-json' })
  hpi: {
    onset: string;
    location: string;
    duration: string;
    character: string;
    aggravatingFactors: string;
    relievingFactors: string;
    timing: string;
    severity: number;
    associatedSymptoms: string[];
  };

  // Review of Systems (ROS)
  @Column({ type: 'simple-json' })
  reviewOfSystems: Record<string, string[]>;

  // Medical History
  @Column({ type: 'simple-json' })
  medicalHistory: {
    conditions: Array<{
      name: string;
      icdCode?: string;
      diagnosedDate?: string;
    }>;
    surgeries: Array<{
      name: string;
      date?: string;
      notes?: string;
    }>;
    medications: Array<{
      name: string;
      dosage: string;
      frequency: string;
      rxnormCode?: string;
    }>;
    familyHistory: Array<{
      condition: string;
      relation: string;
    }>;
  };

  // Allergies - Critical safety information
  @Column({ type: 'simple-json' })
  allergies: Array<{
    substance: string;
    reaction: string;
    severity: 'mild' | 'moderate' | 'severe';
    type: 'allergy' | 'intolerance';
  }>;

  // Social History
  @Column({ type: 'simple-json', nullable: true })
  socialHistory: {
    smokingStatus: string;
    alcoholUse: string;
    exerciseFrequency: string;
    occupation: string;
  };

  // Clinical completeness score (auto-calculated)
  @Column({ type: 'integer', default: 0 })
  completenessScore: number;

  // Review tracking
  @Column({ type: 'text', nullable: true })
  reviewedBy: string;

  @ManyToOne(() => User, { eager: false })
  @JoinColumn({ name: 'reviewedBy' })
  reviewer: User;

  @Column({ type: 'datetime', nullable: true })
  reviewedAt: Date;

  @Column({ type: 'text', nullable: true })
  reviewNotes: string;

  // Soft delete
  @Column({ type: 'datetime', nullable: true })
  deletedAt: Date | null;

  @Column({ type: 'text', nullable: true })
  createdBy: string;

  @ManyToOne(() => User, { eager: false })
  @JoinColumn({ name: 'createdBy' })
  creator: User;

  @Column({ type: 'text', nullable: true })
  updatedBy: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  /**
   * Calculate clinical completeness score (0-100)
   * Used by REP-02 Clinical Completeness Scorecard
   */
  calculateCompletenessScore(): number {
    let score = 0;
    let totalFields = 0;

    // Chief complaint (required)
    totalFields += 1;
    if (this.chiefComplaint?.trim()) score += 1;

    // HPI fields
    const hpiFields: Array<
      'onset' | 'location' | 'duration' | 'character' |
      'aggravatingFactors' | 'relievingFactors' | 'timing'
    > = [
      'onset', 'location', 'duration', 'character',
      'aggravatingFactors', 'relievingFactors', 'timing',
    ];
    totalFields += hpiFields.length + 1; // +1 for severity
    hpiFields.forEach((field) => {
      if (this.hpi?.[field]?.trim()) score += 1;
    });
    if (this.hpi?.severity && this.hpi.severity > 0) score += 1;

    // Medical history
    totalFields += 4; // conditions, surgeries, medications, family
    if (this.medicalHistory?.conditions?.length > 0) score += 1;
    if (this.medicalHistory?.medications?.length > 0) score += 1;
    if (this.medicalHistory?.surgeries?.length > 0) score += 1;
    if (this.medicalHistory?.familyHistory?.length > 0) score += 1;

    // Allergies (critical - high weight)
    totalFields += 2;
    if (this.allergies?.length > 0) score += 2;

    // Social history
    const socialFields: Array<'smokingStatus' | 'alcoholUse'> = [
      'smokingStatus', 'alcoholUse',
    ];
    totalFields += socialFields.length;
    socialFields.forEach((field) => {
      if (this.socialHistory?.[field]?.trim()) score += 1;
    });

    return Math.round((score / totalFields) * 100);
  }
}
