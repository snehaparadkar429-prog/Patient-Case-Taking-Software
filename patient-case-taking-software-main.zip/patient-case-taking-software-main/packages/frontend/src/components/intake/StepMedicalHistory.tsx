'use client';

import { useState } from 'react';

interface Props {
  formData: any;
  updateFormData: (section: string, data: any) => void;
}

/**
 * Medical History step capturing conditions, surgeries, medications, and family history.
 */
export function IntakeStepMedicalHistory({ formData, updateFormData }: Props) {
  const [activeTab, setActiveTab] = useState<'conditions' | 'surgeries' | 'medications' | 'family'>('conditions');
  const history = formData.medicalHistory;

  const updateHistory = (field: string, data: any) => {
    updateFormData('medicalHistory', { ...history, [field]: data });
  };

  // Conditions
  const [conditionName, setConditionName] = useState('');
  const [conditionIcd, setConditionIcd] = useState('');
  const addCondition = () => {
    if (!conditionName.trim()) return;
    updateHistory('conditions', [
      ...history.conditions,
      { name: conditionName.trim(), icdCode: conditionIcd.trim() || undefined },
    ]);
    setConditionName('');
    setConditionIcd('');
  };

  // Surgeries
  const [surgeryName, setSurgeryName] = useState('');
  const [surgeryDate, setSurgeryDate] = useState('');
  const addSurgery = () => {
    if (!surgeryName.trim()) return;
    updateHistory('surgeries', [
      ...history.surgeries,
      { name: surgeryName.trim(), date: surgeryDate || undefined },
    ]);
    setSurgeryName('');
    setSurgeryDate('');
  };

  // Medications
  const [medName, setMedName] = useState('');
  const [medDosage, setMedDosage] = useState('');
  const [medFrequency, setMedFrequency] = useState('');
  const addMedication = () => {
    if (!medName.trim()) return;
    updateHistory('medications', [
      ...history.medications,
      { name: medName.trim(), dosage: medDosage.trim(), frequency: medFrequency.trim() },
    ]);
    setMedName('');
    setMedDosage('');
    setMedFrequency('');
  };

  // Family history
  const [famCondition, setFamCondition] = useState('');
  const [famRelation, setFamRelation] = useState('');
  const addFamilyHistory = () => {
    if (!famCondition.trim()) return;
    updateHistory('familyHistory', [
      ...history.familyHistory,
      { condition: famCondition.trim(), relation: famRelation.trim() },
    ]);
    setFamCondition('');
    setFamRelation('');
  };

  const removeItem = (field: string, index: number) => {
    const updated = [...history[field as keyof typeof history]];
    updated.splice(index, 1);
    updateHistory(field, updated);
  };

  const tabs = [
    { id: 'conditions' as const, label: 'Conditions', count: history.conditions.length },
    { id: 'surgeries' as const, label: 'Surgeries', count: history.surgeries.length },
    { id: 'medications' as const, label: 'Medications', count: history.medications.length },
    { id: 'family' as const, label: 'Family History', count: history.familyHistory.length },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Medical History</h2>
        <p className="mt-1 text-gray-600">
          Document your past medical conditions, surgeries, current medications, and family history.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-primary-600 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700'
            }`}
          >
            {tab.label}
            {tab.count > 0 && (
              <span className="ml-1.5 inline-flex items-center justify-center w-5 h-5 rounded-full bg-primary-100 text-primary-700 text-xs">
                {tab.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Conditions tab */}
      {activeTab === 'conditions' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={conditionName}
              onChange={(e) => setConditionName(e.target.value)}
              placeholder="Condition name (e.g., Hypertension)"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <input
              type="text"
              value={conditionIcd}
              onChange={(e) => setConditionIcd(e.target.value)}
              placeholder="ICD-10 code (optional)"
              className="w-40 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <button onClick={addCondition} className="btn-primary">Add</button>
          </div>
          {history.conditions.map((item: any, index: number) => (
            <div key={index} className="flex items-center justify-between bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
              <div>
                <span className="font-medium">{item.name}</span>
                {item.icdCode && <span className="ml-2 text-sm text-gray-500">({item.icdCode})</span>}
              </div>
              <button onClick={() => removeItem('conditions', index)} className="text-red-500 hover:text-red-700 text-sm">Remove</button>
            </div>
          ))}
        </div>
      )}

      {/* Surgeries tab */}
      {activeTab === 'surgeries' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={surgeryName}
              onChange={(e) => setSurgeryName(e.target.value)}
              placeholder="Surgery name (e.g., Appendectomy)"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <input
              type="date"
              value={surgeryDate}
              onChange={(e) => setSurgeryDate(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <button onClick={addSurgery} className="btn-primary">Add</button>
          </div>
          {history.surgeries.map((item: any, index: number) => (
            <div key={index} className="flex items-center justify-between bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
              <div>
                <span className="font-medium">{item.name}</span>
                {item.date && <span className="ml-2 text-sm text-gray-500">{item.date}</span>}
              </div>
              <button onClick={() => removeItem('surgeries', index)} className="text-red-500 hover:text-red-700 text-sm">Remove</button>
            </div>
          ))}
        </div>
      )}

      {/* Medications tab */}
      {activeTab === 'medications' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={medName}
              onChange={(e) => setMedName(e.target.value)}
              placeholder="Medication name"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <input
              type="text"
              value={medDosage}
              onChange={(e) => setMedDosage(e.target.value)}
              placeholder="Dosage (e.g., 10mg)"
              className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <input
              type="text"
              value={medFrequency}
              onChange={(e) => setMedFrequency(e.target.value)}
              placeholder="Frequency (e.g., BID)"
              className="w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <button onClick={addMedication} className="btn-primary">Add</button>
          </div>
          {history.medications.map((item: any, index: number) => (
            <div key={index} className="flex items-center justify-between bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
              <div>
                <span className="font-medium">{item.name}</span>
                <span className="ml-2 text-sm text-gray-500">{item.dosage} - {item.frequency}</span>
              </div>
              <button onClick={() => removeItem('medications', index)} className="text-red-500 hover:text-red-700 text-sm">Remove</button>
            </div>
          ))}
        </div>
      )}

      {/* Family History tab */}
      {activeTab === 'family' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            <input
              type="text"
              value={famCondition}
              onChange={(e) => setFamCondition(e.target.value)}
              placeholder="Condition (e.g., Diabetes)"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            />
            <select
              value={famRelation}
              onChange={(e) => setFamRelation(e.target.value)}
              className="w-48 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
            >
              <option value="">Select relation</option>
              <option value="Mother">Mother</option>
              <option value="Father">Father</option>
              <option value="Sibling">Sibling</option>
              <option value="Grandparent">Grandparent</option>
              <option value="Aunt/Uncle">Aunt/Uncle</option>
              <option value="Other">Other</option>
            </select>
            <button onClick={addFamilyHistory} className="btn-primary">Add</button>
          </div>
          {history.familyHistory.map((item: any, index: number) => (
            <div key={index} className="flex items-center justify-between bg-gray-50 px-4 py-2 rounded-lg border border-gray-200">
              <div>
                <span className="font-medium">{item.condition}</span>
                <span className="ml-2 text-sm text-gray-500">{item.relation}</span>
              </div>
              <button onClick={() => removeItem('familyHistory', index)} className="text-red-500 hover:text-red-700 text-sm">Remove</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
