'use client';

interface Props {
  formData: any;
  updateFormData: (section: string, data: any) => void;
}

/**
 * INT-02: Chief Complaint capture step.
 * First impression of the patient's reason for visit.
 */
export function IntakeStepChiefComplaint({ formData, updateFormData }: Props) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Chief Complaint</h2>
        <p className="mt-1 text-gray-600">
          What is the main reason for your visit today? Please describe your primary concern.
        </p>
      </div>

      <div>
        <label htmlFor="chiefComplaint" className="block text-sm font-medium text-gray-700 mb-1">
          Primary Reason for Visit <span className="text-red-500">*</span>
        </label>
        <textarea
          id="chiefComplaint"
          rows={4}
          required
          value={formData.chiefComplaint}
          onChange={(e) => updateFormData('chiefComplaint', e.target.value)}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm
                   focus:ring-2 focus:ring-primary-500 focus:border-primary-500
                   text-gray-900 placeholder-gray-400 resize-none"
          placeholder="e.g., I've been having severe headaches for the past week, mostly on the right side..."
          aria-required="true"
        />
        <p className="mt-1 text-xs text-gray-500">
          Be as specific as possible. Include when it started, where it hurts, and what it feels like.
        </p>
      </div>

      {/* Quick-select common chief complaints */}
      <div>
        <p className="text-sm font-medium text-gray-700 mb-2">Common Chief Complaints:</p>
        <div className="flex flex-wrap gap-2">
          {[
            'Headache', 'Chest pain', 'Abdominal pain', 'Shortness of breath',
            'Back pain', 'Fever', 'Cough', 'Fatigue', 'Dizziness', 'Joint pain',
          ].map((complaint) => (
            <button
              key={complaint}
              type="button"
              onClick={() =>
                updateFormData(
                  'chiefComplaint',
                  formData.chiefComplaint
                    ? `${formData.chiefComplaint}, ${complaint.toLowerCase()}`
                    : complaint.toLowerCase()
                )
              }
              className="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded-full
                       hover:bg-primary-50 hover:text-primary-700 transition-colors
                       border border-gray-200 hover:border-primary-300"
            >
              {complaint}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
