import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';
import { UserRole } from '@pct/shared';

/**
 * HIPAA § 164.312(a)(1): Access Control
 * User entity with role-based access control (RBAC).
 * Passwords are bcrypt-hashed with salt rounds >= 12.
 * All PHI access is tied to user identity for audit logging.
 */
@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ unique: true, length: 255 })
  email: string;

  // HIPAA: Passwords stored with bcrypt (cost factor 12)
  // Never store plaintext passwords
  @Column({ select: false, length: 255 })
  passwordHash: string;

  @Column({ length: 100 })
  firstName: string;

  @Column({ length: 100 })
  lastName: string;

  @Column({ type: 'simple-enum', enum: UserRole, default: UserRole.PATIENT })
  role: UserRole;

  @Column({ type: 'text', nullable: true })
  facilityId: string;

  // HIPAA § 164.312(a)(2)(ii): Emergency Access Procedure
  @Column({ default: false })
  isBreakGlassAuthorized: boolean;

  // Account lockout after failed attempts
  @Column({ default: 0 })
  failedLoginAttempts: number;

  @Column({ type: 'datetime', nullable: true })
  lockedUntil: Date | null;

  // MFA support
  @Column({ default: false })
  mfaEnabled: boolean;

  @Column({ type: 'text', select: false, nullable: true, length: 255 })
  mfaSecret: string | null;

  @Column({ default: true })
  isActive: boolean;

  @Column({ default: true })
  isFirstLogin: boolean;

  // Soft delete - HIPAA requires data retention
  @Column({ type: 'datetime', nullable: true })
  deletedAt: Date | null;

  @Column({ type: 'text', nullable: true })
  createdBy: string;

  @Column({ type: 'text', nullable: true })
  updatedBy: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
