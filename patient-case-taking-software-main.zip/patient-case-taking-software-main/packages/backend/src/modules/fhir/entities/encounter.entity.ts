import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm';
import { Patient } from '../../patients/entities/patient.entity';

/**
 * FHIR R4 Encounter Resource
 * Maps to HL7 FHIR R4 Encounter resource for EHR interoperability.
 */
@Entity('encounters')
@Index(['patientId'])
@Index(['status'])
@Index(['periodStart'])
export class Encounter {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'text' })
  patientId: string;

  @ManyToOne(() => Patient)
  @JoinColumn({ name: 'patientId' })
  patient: Patient;

  // FHIR Encounter.status
  @Column({ length: 50, default: 'planned' })
  status: string;

  // FHIR Encounter.class (SNOMED-CT / ActCode)
  @Column({ type: 'simple-json' })
  class: { system: string; code: string; display: string };

  // FHIR Encounter.type
  @Column({ type: 'simple-json', nullable: true })
  type: Array<{
    coding: Array<{ system: string; code: string; display?: string }>;
  }>;

  // FHIR Encounter.period
  @Column({ type: 'datetime', nullable: true })
  periodStart: Date;

  @Column({ type: 'datetime', nullable: true })
  periodEnd: Date;

  // FHIR Encounter.serviceProvider
  @Column({ type: 'text', nullable: true })
  facilityId: string;

  // Clinician assigned
  @Column({ type: 'text', nullable: true })
  clinicianId: string;

  // Reason for visit
  @Column({ type: 'text', nullable: true })
  reasonCode: string;

  @Column({ default: true })
  active: boolean;

  @CreateDateColumn()
  createdAt: Date;
}
