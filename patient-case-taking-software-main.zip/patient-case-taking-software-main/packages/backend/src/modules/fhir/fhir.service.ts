import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Encounter } from './entities/encounter.entity';
import { Condition } from './entities/condition.entity';
import { AllergyIntolerance } from './entities/allergy-intolerance.entity';
import { Observation } from './entities/observation.entity';
import { AuditService } from '../audit/audit.service';
import { AuditAction, UserRole } from '@pct/shared';

/**
 * FHIR R4 Interoperability service.
 * Provides FHIR-formatted resources for EHR integration.
 * DAT-01: FHIR R4 Core Data Store
 */
@Injectable()
export class FhirService {
  constructor(
    @InjectRepository(Encounter)
    private encounterRepo: Repository<Encounter>,
    @InjectRepository(Condition)
    private conditionRepo: Repository<Condition>,
    @InjectRepository(AllergyIntolerance)
    private allergyRepo: Repository<AllergyIntolerance>,
    @InjectRepository(Observation)
    private observationRepo: Repository<Observation>,
    private auditService: AuditService
  ) {}

  /**
   * Create a FHIR Encounter resource.
   */
  async createEncounter(
    data: Partial<Encounter>,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<any> {
    const encounter = this.encounterRepo.create(data);
    const saved = await this.encounterRepo.save(encounter);

    await this.auditService.log({
      action: AuditAction.CREATE,
      resourceType: 'Encounter',
      resourceId: saved.id,
      userId,
      userRole,
      ipAddress,
      patientId: data.patientId,
      status: 'SUCCESS',
    });

    return this.toFhirEncounter(saved);
  }

  /**
   * Get FHIR Encounter resource.
   */
  async getEncounter(
    id: string,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<any> {
    const encounter = await this.encounterRepo.findOne({ where: { id } });

    if (!encounter) return null;

    await this.auditService.log({
      action: AuditAction.READ,
      resourceType: 'Encounter',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      patientId: encounter.patientId,
      status: 'SUCCESS',
    });

    return this.toFhirEncounter(encounter);
  }

  /**
   * Get all conditions for a patient in FHIR format.
   */
  async getPatientConditions(patientId: string): Promise<any> {
    const conditions = await this.conditionRepo.find({
      where: { patientId },
      order: { createdAt: 'DESC' },
    });

    return {
      resourceType: 'Bundle',
      type: 'searchset',
      total: conditions.length,
      entry: conditions.map((c) => ({
        resource: this.toFhirCondition(c),
      })),
    };
  }

  /**
   * Get all allergies for a patient in FHIR format.
   */
  async getPatientAllergies(patientId: string): Promise<any> {
    const allergies = await this.allergyRepo.find({
      where: { patientId },
      order: { createdAt: 'DESC' },
    });

    return {
      resourceType: 'Bundle',
      type: 'searchset',
      total: allergies.length,
      entry: allergies.map((a) => ({
        resource: this.toFhirAllergy(a),
      })),
    };
  }

  /**
   * Get observations (vitals, labs) for a patient in FHIR format.
   */
  async getPatientObservations(patientId: string, category?: string): Promise<any> {
    const query = this.observationRepo.createQueryBuilder('obs')
      .where('obs.patientId = :patientId', { patientId })
      .orderBy('obs.effectiveDateTime', 'DESC');

    if (category) {
      query.andWhere("obs.category @> :category", { category: [{ coding: [{ code: category }] }] });
    }

    const observations = await query.getMany();

    return {
      resourceType: 'Bundle',
      type: 'searchset',
      total: observations.length,
      entry: observations.map((o) => ({
        resource: this.toFhirObservation(o),
      })),
    };
  }

  // ---- FHIR Resource Mappers ----

  private toFhirEncounter(e: Encounter): any {
    return {
      resourceType: 'Encounter',
      id: e.id,
      status: e.status,
      class: e.class,
      type: e.type,
      subject: { reference: `Patient/${e.patientId}` },
      period: {
        start: e.periodStart?.toISOString(),
        end: e.periodEnd?.toISOString(),
      },
    };
  }

  private toFhirCondition(c: Condition): any {
    return {
      resourceType: 'Condition',
      id: c.id,
      clinicalStatus: c.clinicalStatus,
      verificationStatus: c.verificationStatus,
      code: c.code,
      subject: { reference: `Patient/${c.patientId}` },
      onsetDateTime: c.onsetDateTime?.toISOString(),
    };
  }

  private toFhirAllergy(a: AllergyIntolerance): any {
    return {
      resourceType: 'AllergyIntolerance',
      id: a.id,
      clinicalStatus: a.clinicalStatus,
      verificationStatus: a.verificationStatus,
      type: a.type,
      category: a.category,
      criticality: a.criticality,
      code: a.code,
      patient: { reference: `Patient/${a.patientId}` },
      reaction: a.reaction,
    };
  }

  private toFhirObservation(o: Observation): any {
    return {
      resourceType: 'Observation',
      id: o.id,
      status: o.status,
      category: o.category,
      code: o.code,
      subject: { reference: `Patient/${o.patientId}` },
      effectiveDateTime: o.effectiveDateTime?.toISOString(),
      valueQuantity: o.valueQuantity,
      valueString: o.valueString,
    };
  }
}
