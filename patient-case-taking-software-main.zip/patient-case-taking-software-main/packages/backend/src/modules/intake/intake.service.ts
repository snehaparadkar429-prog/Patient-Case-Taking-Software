import {
  Injectable,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, IsNull } from 'typeorm';
import { IntakeForm } from './entities/intake-form.entity';
import { AuditService } from '../audit/audit.service';
import { AuditAction, IntakeStatus, UserRole } from '@pct/shared';

/**
 * HIPAA § 164.312(a)(1): Access Control
 * Intake form service managing clinical documentation workflows.
 * All PHI access is audit-logged.
 */
@Injectable()
export class IntakeService {
  constructor(
    @InjectRepository(IntakeForm)
    private intakeRepository: Repository<IntakeForm>,
    private auditService: AuditService
  ) {}

  /**
   * Create a new intake form.
   * Automatically calculates completeness score.
   */
  async create(
    data: Partial<IntakeForm>,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<IntakeForm> {
    const form = this.intakeRepository.create({
      ...data,
      status: IntakeStatus.DRAFT,
      createdBy: userId,
      updatedBy: userId,
    });

    // Auto-calculate completeness score
    form.completenessScore = form.calculateCompletenessScore();

    const saved = await this.intakeRepository.save(form);

    await this.auditService.log({
      action: AuditAction.CREATE,
      resourceType: 'IntakeForm',
      resourceId: saved.id,
      userId,
      userRole,
      ipAddress,
      patientId: data.patientId,
      status: 'SUCCESS',
    });

    return saved;
  }

  /**
   * Find intake form by ID with access control.
   */
  async findOne(
    id: string,
    userId: string,
    userRole: UserRole,
    ipAddress: string,
    userAgent: string
  ): Promise<IntakeForm> {
    const form = await this.intakeRepository.findOne({
      where: { id, deletedAt: IsNull() },
    });

    if (!form) {
      throw new NotFoundException(`Intake form ${id} not found`);
    }

    // HIPAA: Patients can only view their own forms
    if (userRole === UserRole.PATIENT && form.createdBy !== userId) {
      throw new ForbiddenException('Access denied to this intake form');
    }

    await this.auditService.log({
      action: AuditAction.READ,
      resourceType: 'IntakeForm',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      userAgent,
      patientId: form.patientId,
      encounterId: form.encounterId,
      status: 'SUCCESS',
    });

    return form;
  }

  /**
   * Update intake form data with completeness recalculation.
   */
  async update(
    id: string,
    data: Partial<IntakeForm>,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<IntakeForm> {
    const form = await this.intakeRepository.findOne({
      where: { id, deletedAt: IsNull() },
    });

    if (!form) {
      throw new NotFoundException(`Intake form ${id} not found`);
    }

    if (userRole === UserRole.PATIENT && form.createdBy !== userId) {
      throw new ForbiddenException('Access denied to this intake form');
    }

    Object.assign(form, data, {
      updatedBy: userId,
      status: IntakeStatus.IN_PROGRESS,
    });

    form.completenessScore = form.calculateCompletenessScore();

    const saved = await this.intakeRepository.save(form);

    await this.auditService.log({
      action: AuditAction.UPDATE,
      resourceType: 'IntakeForm',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      patientId: form.patientId,
      status: 'SUCCESS',
    });

    return saved;
  }

  /**
   * Submit completed intake form for clinical review.
   */
  async submit(
    id: string,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<IntakeForm> {
    const form = await this.intakeRepository.findOne({
      where: { id, deletedAt: IsNull() },
    });

    if (!form) {
      throw new NotFoundException(`Intake form ${id} not found`);
    }

    form.status = IntakeStatus.COMPLETED;
    form.updatedBy = userId;

    const saved = await this.intakeRepository.save(form);

    await this.auditService.log({
      action: AuditAction.UPDATE,
      resourceType: 'IntakeForm',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      patientId: form.patientId,
      reason: 'Intake form submitted for review',
      status: 'SUCCESS',
    });

    return saved;
  }

  /**
   * Review intake form (clinician/admin only).
   */
  async review(
    id: string,
    reviewNotes: string,
    userId: string,
    userRole: UserRole,
    ipAddress: string,
    approve: boolean = true
  ): Promise<IntakeForm> {
    const form = await this.intakeRepository.findOne({
      where: { id, deletedAt: IsNull() },
    });

    if (!form) {
      throw new NotFoundException(`Intake form ${id} not found`);
    }

    form.status = approve ? IntakeStatus.REVIEWED : IntakeStatus.REJECTED;
    form.reviewedBy = userId;
    form.reviewedAt = new Date();
    form.reviewNotes = reviewNotes;
    form.updatedBy = userId;

    const saved = await this.intakeRepository.save(form);

    await this.auditService.log({
      action: AuditAction.UPDATE,
      resourceType: 'IntakeForm',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      patientId: form.patientId,
      reason: approve ? 'Intake form approved' : 'Intake form rejected',
      status: 'SUCCESS',
    });

    return saved;
  }

  /**
   * List intake forms with filtering.
   */
  async findAll(
    userId: string,
    userRole: UserRole,
    filters: {
      patientId?: string;
      status?: IntakeStatus;
      page?: number;
      limit?: number;
    }
  ): Promise<{ forms: IntakeForm[]; total: number }> {
    const page = filters.page || 1;
    const limit = Math.min(filters.limit || 20, 100);

    const query = this.intakeRepository
      .createQueryBuilder('form')
      .where('form.deletedAt IS NULL');

    if (userRole === UserRole.PATIENT) {
      query.andWhere('form.createdBy = :userId', { userId });
    }

    if (filters.patientId) {
      query.andWhere('form.patientId = :patientId', {
        patientId: filters.patientId,
      });
    }

    if (filters.status) {
      query.andWhere('form.status = :status', { status: filters.status });
    }

    query.orderBy('form.createdAt', 'DESC');
    query.skip((page - 1) * limit);
    query.take(limit);

    const [forms, total] = await query.getManyAndCount();

    return { forms, total };
  }

  /**
   * REP-02: Clinical Completeness Scorecard
   * Get completeness statistics for a patient's intake forms.
   */
  async getCompletenessStats(patientId: string): Promise<{
    averageScore: number;
    totalForms: number;
    completedForms: number;
    missingCriticalFields: string[];
  }> {
    const forms = await this.intakeRepository.find({
      where: { patientId, deletedAt: IsNull() },
      order: { createdAt: 'DESC' },
    });

    if (forms.length === 0) {
      return {
        averageScore: 0,
        totalForms: 0,
        completedForms: 0,
        missingCriticalFields: [],
      };
    }

    const avgScore =
      forms.reduce((sum, f) => sum + f.completenessScore, 0) / forms.length;

    const completedCount = forms.filter(
      (f) => f.status === IntakeStatus.COMPLETED || f.status === IntakeStatus.REVIEWED
    ).length;

    // Check latest form for missing critical fields
    const latestForm = forms[0];
    const missingFields: string[] = [];

    if (!latestForm.allergies || latestForm.allergies.length === 0) {
      missingFields.push('Allergies documentation');
    }
    if (
      !latestForm.medicalHistory?.medications ||
      latestForm.medicalHistory.medications.length === 0
    ) {
      missingFields.push('Current medications');
    }
    if (!latestForm.hpi?.severity || latestForm.hpi.severity === 0) {
      missingFields.push('Pain severity assessment');
    }

    return {
      averageScore: Math.round(avgScore),
      totalForms: forms.length,
      completedForms: completedCount,
      missingCriticalFields: missingFields,
    };
  }
}
