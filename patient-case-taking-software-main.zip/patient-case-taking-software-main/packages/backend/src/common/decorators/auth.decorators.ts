import { SetMetadata } from '@nestjs/common';
import { UserRole } from '@pct/shared';

// RBAC decorators for fine-grained access control

export const ROLES_KEY = 'roles';
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);

export const PERMISSIONS_KEY = 'permissions';
export const RequirePermissions = (...permissions: string[]) =>
  SetMetadata(PERMISSIONS_KEY, permissions);

// HIPAA § 164.312(a)(2)(i): Emergency access - break glass decorator
export const BREAK_GLASS_KEY = 'breakGlass';
export const RequireBreakGlass = () => SetMetadata(BREAK_GLASS_KEY, true);
