'use client';

interface Props {
  formData: any;
  updateFormData: (section: string, data: any) => void;
}

/**
 * Social History step - lifestyle factors affecting clinical care.
 */
export function IntakeStepSocialHistory({ formData, updateFormData }: Props) {
  const social = formData.socialHistory || {};

  const updateSocial = (field: string, value: string) => {
    updateFormData('socialHistory', { ...social, [field]: value });
  };

  const smokingOptions = [
    'Never smoker',
    'Former smoker (quit within 1 year)',
    'Former smoker (quit more than 1 year ago)',
    'Current smoker (< 1 pack/day)',
    'Current smoker (1+ pack/day)',
    'Occasional/social smoker',
  ];

  const alcoholOptions = [
    'None',
    'Occasional (1-2 drinks/week)',
    'Moderate (3-7 drinks/week)',
    'Heavy (8-14 drinks/week)',
    'Very heavy (15+ drinks/week)',
    'Former drinker (in recovery)',
  ];

  const exerciseOptions = [
    'Sedentary (no regular exercise)',
    'Light (1-2 days/week)',
    'Moderate (3-4 days/week)',
    'Active (5-6 days/week)',
    'Very active (daily intense exercise)',
  ];

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Social History</h2>
        <p className="mt-1 text-gray-600">
          Lifestyle factors that may affect your health and treatment.
        </p>
      </div>

      {/* Smoking Status */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Tobacco / Smoking Status
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {smokingOptions.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => updateSocial('smokingStatus', option)}
              className={`text-left px-4 py-2.5 rounded-lg border text-sm transition-colors ${
                social.smokingStatus === option
                  ? 'bg-primary-50 border-primary-300 text-primary-700 font-medium'
                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {social.smokingStatus === option && '✓ '}{option}
            </button>
          ))}
        </div>
      </div>

      {/* Alcohol Use */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Alcohol Use
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {alcoholOptions.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => updateSocial('alcoholUse', option)}
              className={`text-left px-4 py-2.5 rounded-lg border text-sm transition-colors ${
                social.alcoholUse === option
                  ? 'bg-primary-50 border-primary-300 text-primary-700 font-medium'
                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {social.alcoholUse === option && '✓ '}{option}
            </button>
          ))}
        </div>
      </div>

      {/* Exercise */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Exercise / Physical Activity
        </label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {exerciseOptions.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => updateSocial('exerciseFrequency', option)}
              className={`text-left px-4 py-2.5 rounded-lg border text-sm transition-colors ${
                social.exerciseFrequency === option
                  ? 'bg-primary-50 border-primary-300 text-primary-700 font-medium'
                  : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}
            >
              {social.exerciseFrequency === option && '✓ '}{option}
            </button>
          ))}
        </div>
      </div>

      {/* Occupation */}
      <div>
        <label htmlFor="occupation" className="block text-sm font-medium text-gray-700 mb-1">
          Occupation
        </label>
        <input
          id="occupation"
          type="text"
          value={social.occupation || ''}
          onChange={(e) => updateSocial('occupation', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
          placeholder="e.g., Office worker, Teacher, Construction"
        />
      </div>
    </div>
  );
}
