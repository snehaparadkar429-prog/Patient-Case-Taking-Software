import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  Index,
} from 'typeorm';
import { AuditAction } from '@pct/shared';

/**
 * HIPAA § 164.312(b): Audit Controls
 * Immutable audit log entity. This is an append-only table that records
 * every access to PHI. In production, use Amazon QLDB or a similar
 * immutable ledger to prevent tampering.
 *
 * HIPAA § 164.312(b) requires hardware, software, and/or procedural
 * mechanisms that record and examine activity in systems containing PHI.
 */
@Entity('audit_logs')
@Index(['userId'])
@Index(['patientId'])
@Index(['action'])
@Index(['timestamp'])
@Index(['resourceType', 'resourceId'])
@Index(['ipAddress'])
export class AuditLog {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // Unique event identifier for correlation
  @Column({ unique: true, length: 100 })
  eventId: string;

  // Event timestamp - use UTC
  @Column({ type: 'datetime' })
  timestamp: Date;

  // HIPAA-required action classification
  @Column({ type: 'simple-enum', enum: AuditAction })
  action: AuditAction;

  // Resource type accessed (Patient, Encounter, etc.)
  @Column({ length: 100, nullable: true })
  resourceType: string;

  // Specific resource ID
  @Column({ length: 100, nullable: true })
  resourceId: string;

  // Actor information - WHO performed the action
  @Column({ type: 'text', nullable: true })
  userId: string;

  @Column({ length: 100, nullable: true })
  userRole: string;

  // Network context for anomaly detection
  @Column({ length: 45, nullable: true }) // IPv6 max length
  ipAddress: string;

  @Column({ length: 500, nullable: true })
  userAgent: string;

  // Patient context - which patient's PHI was accessed
  @Column({ type: 'text', nullable: true })
  patientId: string;

  // Encounter context
  @Column({ type: 'text', nullable: true })
  encounterId: string;

  // Facility context
  @Column({ type: 'text', nullable: true })
  facilityId: string;

  // Reason for access (required for break-glass)
  @Column({ length: 500, nullable: true })
  reason: string;

  // Outcome
  @Column({ length: 20, default: 'SUCCESS' })
  status: string;

  // Error details (without PHI)
  @Column({ length: 500, nullable: true })
  errorMessage: string;

  // Break-glass specific fields
  @Column({ default: false })
  isBreakGlass: boolean;

  @Column({ type: 'text', nullable: true })
  breakGlassJustification: string;

  // Request metadata
  @Column({ length: 500, nullable: true })
  requestPath: string;

  @Column({ length: 10, nullable: true })
  requestMethod: string;

  // Performance tracking
  @Column({ type: 'integer', nullable: true })
  responseTimeMs: number;

  // HIPAA: Never store PHI directly in audit logs
  // Only reference patient/resource IDs

  @CreateDateColumn()
  createdAt: Date;
}
