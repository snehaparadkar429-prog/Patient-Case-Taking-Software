import {
  Controller,
  Get,
  Query,
  UseGuards,
  Req,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { Request } from 'express';
import { AuditService } from './audit.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/auth.decorators';
import { CurrentUser } from '../../common/decorators/user.decorator';
import { UserRole } from '@pct/shared';

/**
 * HIPAA § 164.312(b): Audit Controls
 * HIPAA § 164.308(a)(1)(ii)(D): Information System Activity Review
 *
 * Audit log controller for compliance officers and administrators.
 * Provides read-only access to the immutable audit trail.
 */
@Controller('audit')
@UseGuards(JwtAuthGuard, RolesGuard)
export class AuditController {
  constructor(private auditService: AuditService) {}

  /**
   * GET /api/v1/audit
   * Query audit logs with filters. Restricted to compliance officers and admins.
   */
  @Get()
  @Roles(UserRole.COMPLIANCE_OFFICER, UserRole.ADMINISTRATOR, UserRole.SYSTEM_ADMIN)
  async findAll(
    @Query('userId') userId?: string,
    @Query('patientId') patientId?: string,
    @Query('action') action?: string,
    @Query('resourceType') resourceType?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('ipAddress') ipAddress?: string,
    @Query('isBreakGlass') isBreakGlass?: string,
    @Query('page') page?: string,
    @Query('limit') limit?: string
  ) {
    return this.auditService.findAll({
      userId,
      patientId,
      action: action as any,
      resourceType,
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      ipAddress,
      isBreakGlass: isBreakGlass === 'true' ? true : isBreakGlass === 'false' ? false : undefined,
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 50,
    });
  }

  /**
   * GET /api/v1/audit/anomaly-stats
   * SEC-03: HIPAA Access & Anomaly Reports
   */
  @Get('anomaly-stats')
  @Roles(UserRole.COMPLIANCE_OFFICER, UserRole.ADMINISTRATOR)
  async getAnomalyStats(
    @Query('facilityId') facilityId: string,
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string
  ) {
    return this.auditService.getAnomalyStats(facilityId, {
      start: new Date(startDate),
      end: new Date(endDate),
    });
  }

  /**
   * GET /api/v1/audit/bulk-access-check
   * SEC-03: Detect unusual bulk data access patterns.
   */
  @Get('bulk-access-check')
  @Roles(UserRole.COMPLIANCE_OFFICER)
  async checkBulkAccess(
    @Query('userId') userId: string,
    @Query('hoursBack') hoursBack?: string
  ) {
    return this.auditService.detectBulkAccess(
      userId,
      hoursBack ? parseInt(hoursBack, 10) : 1
    );
  }

  /**
   * GET /api/v1/audit/retention
   * Audit log retention statistics for compliance.
   */
  @Get('retention')
  @Roles(UserRole.COMPLIANCE_OFFICER, UserRole.SYSTEM_ADMIN)
  async getRetentionStats() {
    return this.auditService.getRetentionStats();
  }
}
