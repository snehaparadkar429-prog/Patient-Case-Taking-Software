import { NextRequest, NextResponse } from 'next/server';

/**
 * HIPAA API Proxy Route
 *
 * Proxies all /api/* requests from the frontend to the backend NestJS server.
 * This eliminates CORS issues and CSP connect-src restrictions because the
 * browser sees same-origin requests to /api/* which are then server-side
 * forwarded to the actual backend.
 *
 * Architecture:
 *   Browser -> Next.js (/api/v1/*) -> Backend (http://localhost:3001/api/v1/*)
 *
 * Without this proxy, the browser makes direct cross-origin requests to
 * localhost:3001, which are blocked by CSP connect-src 'self' and CORS.
 */

const BACKEND_URL = process.env.BACKEND_INTERNAL_URL || 'http://localhost:3001';

export async function GET(
  request: NextRequest,
  { params }: { params: { proxy: string[] } }
) {
  return proxyRequest(request, params.proxy);
}

export async function POST(
  request: NextRequest,
  { params }: { params: { proxy: string[] } }
) {
  return proxyRequest(request, params.proxy);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { proxy: string[] } }
) {
  return proxyRequest(request, params.proxy);
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: { proxy: string[] } }
) {
  return proxyRequest(request, params.proxy);
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { proxy: string[] } }
) {
  return proxyRequest(request, params.proxy);
}

async function proxyRequest(
  request: NextRequest,
  proxySegments: string[]
): Promise<NextResponse> {
  // Reconstruct the backend URL
  const apiPath = proxySegments.join('/');
  const backendUrl = `${BACKEND_URL}/api/v1/${apiPath}`;

  // Forward the query string
  const searchParams = request.nextUrl.searchParams.toString();
  const url = searchParams ? `${backendUrl}?${searchParams}` : backendUrl;

  // Forward relevant headers (Authorization is critical for auth)
  const headers = new Headers();
  const authHeader = request.headers.get('authorization');
  if (authHeader) {
    headers.set('authorization', authHeader);
  }
  headers.set('content-type', request.headers.get('content-type') || 'application/json');

  // Forward client IP for audit logging
  const forwardedFor = request.headers.get('x-forwarded-for');
  if (forwardedFor) {
    headers.set('x-forwarded-for', forwardedFor);
  }

  try {
    // Forward the request body for POST/PUT/PATCH
    let body: BodyInit | undefined;
    if (['POST', 'PUT', 'PATCH'].includes(request.method)) {
      body = await request.text();
    }

    const response = await fetch(url, {
      method: request.method,
      headers,
      body,
    });

    // Stream the backend response back to the browser
    const responseBody = await response.text();

    return new NextResponse(responseBody, {
      status: response.status,
      statusText: response.statusText,
      headers: {
        'content-type': response.headers.get('content-type') || 'application/json',
      },
    });
  } catch (error) {
    console.error(`[API Proxy] Error forwarding to ${url}:`, error);
    return NextResponse.json(
      {
        message: 'Backend service is unavailable. Please ensure the API server is running on port 3001.',
        statusCode: 502,
      },
      { status: 502 }
    );
  }
}
