import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';
import { FhirPatient } from '@pct/shared';

/**
 * HIPAA § 164.312(a)(1): Access Control
 * Patient entity storing PHI (Protected Health Information).
 * FHIR R4 Patient resource mapping with field-level encryption support.
 *
 * HIPAA § 164.312(e)(1): Encryption at Rest
 * High-risk PHI fields (SSN, DOB) should use pgcrypto column encryption
 * in production via application-level encryption or column encryption.
 */
@Entity('patients')
@Index(['familyName', 'givenName'])
@Index(['dateOfBirth'])
@Index(['medicalRecordNumber'], { unique: true, where: '"medicalRecordNumber" IS NOT NULL' })
export class Patient {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // HIPAA § 164.514(h): De-identification - Master Patient Index key
  @Column({ unique: true, length: 50, nullable: true })
  medicalRecordNumber: string;

  // FHIR Patient.identifier
  @Column({ type: 'simple-json', nullable: true })
  identifiers: Array<{ system: string; value: string }>;

  @Column({ default: true })
  active: boolean;

  // Patient name (FHIR HumanName)
  @Column({ length: 100 })
  familyName: string;

  @Column({ length: 100 })
  givenName: string;

  @Column({ length: 20, nullable: true })
  prefix: string;

  @Column({ length: 20, nullable: true })
  suffix: string;

  @Column({ type: 'simple-enum', enum: ['male', 'female', 'other', 'unknown'] })
  gender: string;

  // HIPAA: Date of Birth is PHI - encryption at rest recommended
  @Column({ type: 'date' })
  dateOfBirth: string;

  // FHIR Patient.telecom
  @Column({ type: 'simple-json' })
  telecom: Array<{ system: string; value: string; use?: string }>;

  // FHIR Patient.address
  @Column({ type: 'simple-json' })
  addresses: Array<{
    use?: string;
    line?: string[];
    city: string;
    state: string;
    postalCode: string;
    country?: string;
  }>;

  // HIPAA: Emergency contact information
  @Column({ type: 'simple-json', nullable: true })
  contacts: Array<{
    relationship?: string;
    name?: string;
    phone?: string;
    email?: string;
  }>;

  // FHIR Patient.maritalStatus
  @Column({ length: 50, nullable: true })
  maritalStatus: string;

  // HIPAA: Language preference for accessibility
  @Column({ length: 10, nullable: true, default: 'en' })
  preferredLanguage: string;

  // FHIR Patient.photo (stored as URL reference, not binary)
  @Column({ nullable: true })
  photoUrl: string;

  // HIPAA § 164.514(h): De-identification support
  @Column({ default: false })
  isDeidentified: boolean;

  // Soft delete - HIPAA requires data retention
  @Column({ type: 'datetime', nullable: true })
  deletedAt: Date | null;

  @Column({ type: 'text', nullable: true })
  createdBy: string;

  @Column({ type: 'text', nullable: true })
  updatedBy: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  /**
   * Convert to FHIR R4 Patient resource for interoperability
   */
  toFhirResource(): FhirPatient {
    return {
      resourceType: 'Patient',
      id: this.id,
      meta: {
        lastUpdated: this.updatedAt?.toISOString(),
        profile: ['http://hl7.org/fhir/us/core/StructureDefinition/us-core-patient'],
      },
      identifier: this.identifiers || [],
      active: this.active,
      name: [
        {
          use: 'official',
          family: this.familyName,
          given: [this.givenName],
          prefix: this.prefix ? [this.prefix] : undefined,
          suffix: this.suffix ? [this.suffix] : undefined,
        },
      ],
      gender: this.gender,
      birthDate: this.dateOfBirth,
      telecom: this.telecom,
      address: this.addresses.map((addr) => ({
        use: addr.use,
        line: addr.line,
        city: addr.city,
        state: addr.state,
        postalCode: addr.postalCode,
        country: addr.country || 'US',
      })),
    };
  }
}
