'use client';

interface Props {
  formData: any;
  updateFormData: (section: string, data: any) => void;
}

/**
 * Final review step showing completeness score and summary.
 * REP-02: Clinical Completeness Scorecard (client-side preview).
 */
export function IntakeStepReview({ formData }: Props) {
  const calculateScore = (): number => {
    let score = 0;
    let total = 0;

    // Chief complaint
    total += 1;
    if (formData.chiefComplaint?.trim()) score += 1;

    // HPI
    const hpiFields = ['onset', 'location', 'duration', 'character', 'aggravatingFactors', 'relievingFactors', 'timing'];
    total += hpiFields.length + 1;
    hpiFields.forEach((f) => {
      if (formData.hpi?.[f]?.trim()) score += 1;
    });
    if (formData.hpi?.severity > 0) score += 1;

    // ROS
    total += 1;
    const rosCount = Object.values(formData.reviewOfSystems || {}).flat().length;
    if (rosCount > 0) score += 1;

    // Medical history
    total += 4;
    if (formData.medicalHistory?.conditions?.length > 0) score += 1;
    if (formData.medicalHistory?.medications?.length > 0) score += 1;
    if (formData.medicalHistory?.surgeries?.length > 0) score += 1;
    if (formData.medicalHistory?.familyHistory?.length > 0) score += 1;

    // Allergies
    total += 2;
    if (formData.allergies?.length > 0) score += 2;

    // Social history
    total += 2;
    if (formData.socialHistory?.smokingStatus) score += 1;
    if (formData.socialHistory?.alcoholUse) score += 1;

    return Math.round((score / total) * 100);
  };

  const score = calculateScore();

  const getScoreColor = () => {
    if (score >= 80) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBg = () => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 50) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const missingItems: string[] = [];
  if (!formData.chiefComplaint?.trim()) missingItems.push('Chief complaint');
  if (!formData.hpi?.onset?.trim()) missingItems.push('HPI - Onset');
  if (!formData.hpi?.location?.trim()) missingItems.push('HPI - Location');
  if (!formData.hpi?.duration?.trim()) missingItems.push('HPI - Duration');
  if (!formData.hpi?.character?.trim()) missingItems.push('HPI - Quality');
  if (formData.allergies?.length === 0) missingItems.push('Allergies (none documented)');
  if (formData.medicalHistory?.medications?.length === 0) missingItems.push('Current medications');
  if (!formData.socialHistory?.smokingStatus) missingItems.push('Smoking status');

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Review & Submit</h2>
        <p className="mt-1 text-gray-600">
          Review your intake information before submitting for clinical review.
        </p>
      </div>

      {/* Completeness Score */}
      <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900">Clinical Completeness Score</h3>
          <span className={`text-3xl font-bold ${getScoreColor()}`}>{score}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className={`h-3 rounded-full transition-all duration-500 ${getScoreBg()}`}
            style={{ width: `${score}%` }}
          />
        </div>
        {missingItems.length > 0 && (
          <div className="mt-4">
            <p className="text-sm font-medium text-gray-700 mb-1">Missing Information:</p>
            <ul className="text-sm text-gray-600 space-y-1">
              {missingItems.map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <span className="text-yellow-500">⚠</span> {item}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Summary sections */}
      <div className="space-y-4">
        {/* Chief Complaint */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h4 className="font-medium text-gray-900 mb-1">Chief Complaint</h4>
          <p className="text-sm text-gray-600">{formData.chiefComplaint || <em className="text-gray-400">Not provided</em>}</p>
        </div>

        {/* HPI Summary */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h4 className="font-medium text-gray-900 mb-2">History of Present Illness</h4>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div><span className="text-gray-500">Severity:</span> <span className="font-medium">{formData.hpi?.severity}/10</span></div>
            <div><span className="text-gray-500">Onset:</span> <span>{formData.hpi?.onset || '-'}</span></div>
            <div><span className="text-gray-500">Location:</span> <span>{formData.hpi?.location || '-'}</span></div>
            <div><span className="text-gray-500">Duration:</span> <span>{formData.hpi?.duration || '-'}</span></div>
            <div><span className="text-gray-500">Quality:</span> <span>{formData.hpi?.character || '-'}</span></div>
            <div><span className="text-gray-500">Timing:</span> <span>{formData.hpi?.timing || '-'}</span></div>
          </div>
        </div>

        {/* Allergies */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h4 className="font-medium text-gray-900 mb-1">
            Allergies ({formData.allergies?.length || 0})
          </h4>
          {formData.allergies?.length > 0 ? (
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.allergies.map((a: any, i: number) => (
                <span
                  key={i}
                  className={`compliance-badge ${
                    a.severity === 'severe'
                      ? 'bg-red-100 text-red-800'
                      : a.severity === 'moderate'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-green-100 text-green-800'
                  }`}
                >
                  {a.substance} ({a.severity})
                </span>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-400">No allergies documented</p>
          )}
        </div>

        {/* Medications */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h4 className="font-medium text-gray-900 mb-1">
            Medications ({formData.medicalHistory?.medications?.length || 0})
          </h4>
          {formData.medicalHistory?.medications?.length > 0 ? (
            <ul className="text-sm text-gray-600 mt-2 space-y-1">
              {formData.medicalHistory.medications.map((m: any, i: number) => (
                <li key={i}>{m.name} - {m.dosage} ({m.frequency})</li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-400">No medications documented</p>
          )}
        </div>
      </div>
    </div>
  );
}
