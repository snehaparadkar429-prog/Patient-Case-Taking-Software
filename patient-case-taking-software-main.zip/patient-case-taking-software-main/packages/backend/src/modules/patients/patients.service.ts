import {
  Injectable,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, IsNull } from 'typeorm';
import { Patient } from './entities/patient.entity';
import { AuditService } from '../audit/audit.service';
import { AuditAction, UserRole } from '@pct/shared';

/**
 * HIPAA § 164.312(a)(1): Access Control
 * Patient service with RBAC enforcement and audit logging.
 * All PHI access is logged via the AuditService.
 */
@Injectable()
export class PatientsService {
  constructor(
    @InjectRepository(Patient)
    private patientRepository: Repository<Patient>,
    private auditService: AuditService
  ) {}

  /**
   * Create a new patient record.
   * HIPAA: Creates a new FHIR Patient resource.
   */
  async create(
    data: Partial<Patient>,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<Patient> {
    const patient = this.patientRepository.create({
      ...data,
      createdBy: userId,
      updatedBy: userId,
    });

    const saved = await this.patientRepository.save(patient);

    // Audit log: PHI creation
    await this.auditService.log({
      action: AuditAction.CREATE,
      resourceType: 'Patient',
      resourceId: saved.id,
      userId,
      userRole,
      ipAddress,
      patientId: saved.id,
      status: 'SUCCESS',
    });

    return saved;
  }

  /**
   * Find patient by ID with access control.
   * HIPAA § 164.312(a)(1): Minimum Necessary Rule enforced.
   */
  async findOne(
    id: string,
    userId: string,
    userRole: UserRole,
    ipAddress: string,
    userAgent: string
  ): Promise<Patient> {
    const patient = await this.patientRepository.findOne({
      where: { id, deletedAt: IsNull() },
    });

    if (!patient) {
      throw new NotFoundException(`Patient ${id} not found`);
    }

    // HIPAA: Patients can only view their own records
    if (userRole === UserRole.PATIENT && patient.createdBy !== userId) {
      throw new ForbiddenException('Access denied to this patient record');
    }

    // Audit log: PHI access
    await this.auditService.log({
      action: AuditAction.READ,
      resourceType: 'Patient',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      userAgent,
      patientId: id,
      status: 'SUCCESS',
    });

    return patient;
  }

  /**
   * Search patients with pagination.
   * HIPAA: Search results are filtered by role-based access.
   */
  async findAll(
    userId: string,
    userRole: UserRole,
    filters: {
      search?: string;
      page?: number;
      limit?: number;
    }
  ): Promise<{ patients: Patient[]; total: number }> {
    const page = filters.page || 1;
    const limit = Math.min(filters.limit || 20, 100);

    const query = this.patientRepository
      .createQueryBuilder('patient')
      .where('patient.deletedAt IS NULL');

    // HIPAA: Patients can only see their own records
    if (userRole === UserRole.PATIENT) {
      query.andWhere('patient.createdBy = :userId', { userId });
    }

    if (filters.search) {
      const searchTerm = `%${filters.search.toLowerCase()}%`;
      query.andWhere(
        '(LOWER(patient.familyName) LIKE :search OR LOWER(patient.givenName) LIKE :search OR LOWER(patient.medicalRecordNumber) LIKE :search)',
        { search: searchTerm }
      );
    }

    query.orderBy('patient.createdAt', 'DESC');
    query.skip((page - 1) * limit);
    query.take(limit);

    const [patients, total] = await query.getManyAndCount();

    return { patients, total };
  }

  /**
   * Update patient record with audit logging.
   */
  async update(
    id: string,
    data: Partial<Patient>,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<Patient> {
    const patient = await this.patientRepository.findOne({
      where: { id, deletedAt: IsNull() },
    });

    if (!patient) {
      throw new NotFoundException(`Patient ${id} not found`);
    }

    if (userRole === UserRole.PATIENT && patient.createdBy !== userId) {
      throw new ForbiddenException('Access denied to this patient record');
    }

    Object.assign(patient, data, { updatedBy: userId });
    const saved = await this.patientRepository.save(patient);

    // Audit log: PHI update
    await this.auditService.log({
      action: AuditAction.UPDATE,
      resourceType: 'Patient',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      patientId: id,
      status: 'SUCCESS',
    });

    return saved;
  }

  /**
   * Soft delete patient record (HIPAA data retention).
   */
  async remove(
    id: string,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ): Promise<void> {
    const patient = await this.patientRepository.findOne({
      where: { id, deletedAt: IsNull() },
    });

    if (!patient) {
      throw new NotFoundException(`Patient ${id} not found`);
    }

    // Only admins can delete patient records
    if (
      userRole !== UserRole.ADMINISTRATOR &&
      userRole !== UserRole.SYSTEM_ADMIN
    ) {
      throw new ForbiddenException('Insufficient permissions to delete patient');
    }

    patient.deletedAt = new Date();
    patient.updatedBy = userId;
    await this.patientRepository.save(patient);

    // Audit log: PHI deletion (soft delete)
    await this.auditService.log({
      action: AuditAction.DELETE,
      resourceType: 'Patient',
      resourceId: id,
      userId,
      userRole,
      ipAddress,
      patientId: id,
      status: 'SUCCESS',
    });
  }

  /**
   * Convert patient to FHIR R4 resource for interoperability.
   */
  async getFhirResource(
    id: string,
    userId: string,
    userRole: UserRole,
    ipAddress: string
  ) {
    const patient = await this.findOne(id, userId, userRole, ipAddress, '');
    return patient.toFhirResource();
  }
}
