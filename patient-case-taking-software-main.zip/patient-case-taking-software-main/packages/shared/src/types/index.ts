export enum UserRole {
  PATIENT = 'patient',
  INTAKE_STAFF = 'intake_staff',
  CLINICIAN = 'clinician',
  NURSE = 'nurse',
  ADMINISTRATOR = 'administrator',
  COMPLIANCE_OFFICER = 'compliance_officer',
  SYSTEM_ADMIN = 'system_admin',
}

export enum ResourceType {
  PATIENT = 'Patient',
  ENCOUNTER = 'Encounter',
  CONDITION = 'Condition',
  ALLERGY_INTOLERANCE = 'AllergyIntolerance',
  OBSERVATION = 'Observation',
  DOCUMENT_REFERENCE = 'DocumentReference',
  MEDICATION_REQUEST = 'MedicationRequest',
  CONSENT = 'Consent',
}

export enum AuditAction {
  CREATE = 'CREATE',
  READ = 'READ',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
  EXPORT = 'EXPORT',
  LOGIN = 'LOGIN',
  LOGOUT = 'LOGOUT',
  BREAK_GLASS = 'BREAK_GLASS',
}

export enum EncounterStatus {
  PLANNED = 'planned',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  CANCELLED = 'cancelled',
}

export enum IntakeStatus {
  DRAFT = 'draft',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  REVIEWED = 'reviewed',
  REJECTED = 'rejected',
}

export interface FhirPatient {
  resourceType: 'Patient';
  id?: string;
  meta?: {
    lastUpdated?: string;
    profile?: string[];
  };
  identifier?: Array<{
    system: string;
    value: string;
  }>;
  active?: boolean;
  name?: Array<{
    use?: string;
    family?: string;
    given?: string[];
    prefix?: string[];
    suffix?: string[];
  }>;
  telecom?: Array<{
    system: string;
    value: string;
    use?: string;
  }>;
  gender?: string;
  birthDate?: string;
  address?: Array<{
    use?: string;
    line?: string[];
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  }>;
  contact?: Array<{
    relationship?: Array<{ coding: Array<{ system: string; code: string }> }>;
    name?: { family?: string; given?: string[] };
    telecom?: Array<{ system: string; value: string }>;
  }>;
}

export interface FhirEncounter {
  resourceType: 'Encounter';
  id?: string;
  status: string;
  class?: { system: string; code: string; display?: string };
  type?: Array<{ coding: Array<{ system: string; code: string; display?: string }> }>;
  subject?: { reference: string };
  period?: { start?: string; end?: string };
}

export interface FhirCondition {
  resourceType: 'Condition';
  id?: string;
  clinicalStatus?: { coding: Array<{ system: string; code: string }> };
  verificationStatus?: { coding: Array<{ system: string; code: string }> };
  code?: { coding: Array<{ system: string; code: string; display?: string }> };
  subject?: { reference: string };
  onsetDateTime?: string;
}

export interface FhirAllergyIntolerance {
  resourceType: 'AllergyIntolerance';
  id?: string;
  clinicalStatus?: { coding: Array<{ system: string; code: string }> };
  verificationStatus?: { coding: Array<{ system: string; code: string }> };
  type?: string;
  category?: string[];
  criticality?: string;
  code?: { coding: Array<{ system: string; code: string; display?: string }> };
  patient?: { reference: string };
}

export interface FhirObservation {
  resourceType: 'Observation';
  id?: string;
  status: string;
  category?: Array<{ coding: Array<{ system: string; code: string }> }>;
  code?: { coding: Array<{ system: string; code: string; display?: string }> };
  subject?: { reference: string };
  effectiveDateTime?: string;
  valueQuantity?: { value: number; unit: string; system?: string; code?: string };
  valueString?: string;
}

export interface IntakeFormData {
  chiefComplaint: string;
  hpi: {
    onset: string;
    location: string;
    duration: string;
    character: string;
    aggravatingFactors: string;
    relievingFactors: string;
    timing: string;
    severity: number;
    associatedSymptoms: string[];
  };
  reviewOfSystems: Record<string, string[]>;
  medicalHistory: {
    conditions: Array<{ name: string; icdCode?: string; diagnosedDate?: string }>;
    surgeries: Array<{ name: string; date?: string; notes?: string }>;
    medications: Array<{ name: string; dosage: string; frequency: string; rxnormCode?: string }>;
    familyHistory: Array<{ condition: string; relation: string }>;
  };
  allergies: Array<{
    substance: string;
    reaction: string;
    severity: 'mild' | 'moderate' | 'severe';
    type: 'allergy' | 'intolerance';
  }>;
  socialHistory: {
    smokingStatus: string;
    alcoholUse: string;
    exerciseFrequency: string;
    occupation: string;
  };
}
