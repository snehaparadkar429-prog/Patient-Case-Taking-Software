const path = require('path');

module.exports = {
  resolve: {
    alias: {
      // Point at compiled dist/, not source files.
      // Compiling shared/src through backend webpack causes conflicts.
      '@pct/shared': path.resolve(__dirname, '../shared/dist'),
    },
    extensions: ['.ts', '.js', '.json'],
  },
  // Native modules must not be bundled by webpack
  externals: {
    'better-sqlite3': 'commonjs better-sqlite3',
    'bcryptjs': 'commonjs bcryptjs',
    'pg': 'commonjs pg',
    'pg-native': 'commonjs pg-native',
  },
  output: {
    filename: 'main.js',
  },
  target: 'node',
  mode: 'development',
};
